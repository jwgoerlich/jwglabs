---
name: "tahiti-hunt-hypothesis"
description: "Create TaHiTI-style threat hunt hypotheses and hunt plans from a trigger (threat intel, monitoring gap, incident, prior hunt) using the Lee & Bianco hypothesis types and quality checks."
---

# TaHiTI threat hunt hypothesis creation

Turn a hunt trigger into one or more strong, testable hypotheses and a ready-to-run hunt card, following the TaHiTI methodology (Targeted Hunting integrating Threat Intelligence, Dutch Payments Association, 2018) and Lee & Bianco, "Generating Hypotheses for Successful Threat Hunting" (SANS, 2016).

TaHiTI has three phases: **Initiate -> Hunt (Define/Refine, then Execute) -> Finalize**. This skill covers Initiate and Define/Refine and sets up Execute and Finalize.

## 1. Gather inputs

Collect what the user has given. Ask at most three short questions, and only for gaps that would change the hypothesis. Otherwise make a reasonable assumption and label it **Assumption** in the output.

- **Trigger:** what prompted this hunt (intel report, new technique, missing detection, incident, earlier hunt).
- **Intel:** actor, campaign, TTPs, IOCs. Note which kill-chain phase each IOC relates to.
- **Environment:** crown jewels and core missions, key technologies in use (OS, cloud, identity, ICS vs. corporate IT), and recent changes (acquisitions, migrations, new connections).
- **Data and tools available:** log sources (Windows events, Sysmon, EDR, DNS, proxy, firewall, email, cloud audit logs) and platforms (SIEM/XDR, ELK, Osquery, Velociraptor, YARA).
- **Constraints:** time window, scope, people available.

Never invent intelligence, IOCs, or environment facts. Cite MITRE ATT&CK technique IDs only when confident; otherwise give the technique name and say to verify the ID.

## 2. Initiate: classify the trigger and write the abstract

Classify the trigger into one of TaHiTI's five categories:
1. Threat intelligence
2. Threat hunting (from a previous hunt)
3. Security monitoring (e.g., a known detection gap)
4. Security incident response
5. Other

Write a 2-3 sentence **abstract**: what started the hunt, what threat it concerns, and why it matters to this organization.

## 3. Generate candidate hypotheses across all three types

Every hypothesis starts from an observation. Draft at least one candidate per type, then one **combined** hypothesis that draws on all three. The combined one is usually strongest.

| Type | Built from | Pattern |
|---|---|---|
| **Intelligence-driven** | Friendly or threat intel: IOCs, TTPs | "Actor X does Y, so if they target us we should see Z in data source D." |
| **Situational awareness** | Crown jewels, environment and business change (including people and process) | "Our most valuable asset / newest change is A, so an adversary would likely do B, visible in D." |
| **Domain expertise** | Hunter's knowledge of a technology and past hunts | "Technology T can be abused via M, so look for anomaly N in D." |

Use IOCs for quick wins, but push hypotheses up the Pyramid of Pain toward behaviors (TTPs). Do not write a hypothesis that requires checking every IOC in a feed.

## 4. Quality gate: keep only strong hypotheses

Score each candidate against these checks. Rewrite or drop any that fail.

- **Testable:** at least a chance of finding it in data you can access, with tools you have.
- **Grounded:** traces back to a real observation, intel item, or environment fact.
- **Relevant:** concerns technology and data actually present; ties to crown jewels where possible.
- **Behavioral:** targets TTPs, not only brittle IOCs.
- **Specific and bounded:** names the data source, the expected evidence, and a time window.
- **Bias-checked:** challenge assumptions from past experience. Structure with the Diamond Model (adversary, infrastructure, capability, victim) and consider whether the environment changes what counts as abnormal (a new shell or account is routine in corporate IT, highly suspect in ICS).

If a good hypothesis is **not testable**, diagnose why and report it as a finding:
- Missing data -> **collection gap** (recommend the log source).
- Missing analytic capability -> **technology gap** (recommend the tool or platform fix).
- Not grounded in reality -> rethink how hypotheses are being generated and prioritized.

Keep strong but unpursued hypotheses in a **Parked for later** list rather than discarding them.

## 5. Define/Refine: turn the chosen hypothesis into a hunt plan

For the primary hypothesis, specify:
- **Data sources:** exact logs and fields (e.g., Sysmon Event ID 1 process creation, DNS query logs, email gateway logs, CloudTrail).
- **Analysis techniques:** searching, least-frequency analysis / stacking, clustering, baselining, visualization. For files and memory, YARA. For endpoints, Osquery or Velociraptor queries.
- **Starter queries:** pseudo-queries or queries in the user's platform if known. Label them as untested.
- **Time window and scope:** e.g., last 90 days, named host groups. This prevents scope creep.
- **Success criteria and stop conditions:** what proves or disproves the hypothesis, and when to stop.
- **Outcome paths:** proven -> hand to incident response. Disproven -> refine and rerun, or close with lessons learned. A "failed" hunt that finds nothing still has value.

## 6. Output: the hunt card

Deliver this in the reply. If the user wants to keep or share it, offer to put it in a document.

```
HUNT: <short name>
Trigger: <TaHiTI category> - <one line>
Abstract: <2-3 sentences>

Primary hypothesis (<type or "combined">):
  <one or two sentences: who/what, behavior, where it would show up>
  ATT&CK: <technique name (ID)>

Quality check: Testable Y/N | Grounded Y/N | Relevant Y/N | Behavioral Y/N | Bounded Y/N | Bias-checked Y/N

Data sources: ...
Analysis techniques: ...
Starter queries: ...
Time window / scope: ...
Success criteria: ...
Stop conditions: ...
If proven: escalate to IR via <path>
If disproven: <refine how> or close with lessons learned

Alternative hypotheses considered: <one line each, with type>
Parked for later: <hypotheses not pursued now, and what they would need>
Gaps found: <collection or technology gaps>
Assumptions: <anything not confirmed by the user>

Finalize (after the hunt): results; recommendations (new detections, new log sources); lessons learned; feedback to monitoring, vuln management, IR, and CTI.
```

## Weak vs. strong example

- **Weak:** "An IOC alert fired for a new file on one domain controller, so it will be on our other domain controllers too." (Single IOC, no context, no adversary goal.)
- **Strong (combined):** Crown jewels analysis says R&D data matters most. Intel says a new group is stealing research from similar organizations with similar malware. Expertise says such groups stage several tools. Hypothesis: "The file is one of several tools; R&D documents are the target and will likely be exfiltrated over encrypted channels. Look for unusual access to R&D shares and new encrypted outbound sessions from hosts that touched them in the last 30 days."

## Principles to keep

- Hypothesis generation is human work; automation supports it but cannot replace it.
- Don't over-invest in generating hypotheses. Get to testing quickly.
- Document everything from abstract to outcome so hunts are repeatable and knowledge outlasts any one analyst.
- Each hunt should feed back: new detections, new log sources, new intel, and triggers for future hunts.

## Sources

- Lee, R. M. & Bianco, D. (2016). *Generating Hypotheses for Successful Threat Hunting.* SANS Institute.
- Dutch Payments Association (Betaalvereniging) (2018). *TaHiTI Threat Hunting Methodology.*
- SANS SEC599, Book 5: Proactive Threat Hunting Strategies.