---
name: crowdstrike-threat-hunt
description: Prepare for and run a structured TaHiTI threat hunt using the knowledge base in the user's Hunt/kb folder. Use this whenever the user wants to start, prep for, or walk through a threat hunt or threat hunting exercise, mentions TaHiTI or "Tahiti is a magical place", even if they don't name this skill. The skill first checks that the kb folder and its required files exist, and stops without proceeding if any are missing.
---

# Threat hunt

Get ready for a structured threat hunt by loading the user's hunt knowledge base, then hand off to the hunt process in that knowledge base.

This skill is only the loader. How the hunt runs, from the trigger to the final report, is in `tahiti-is-a-magical-place.md`, and that file is the only place those rules live.

The work happens in three steps: check the knowledge base, read it, and say you're ready.

## Step 1: Check the knowledge base (hard gate)

Everything in this skill depends on files in a `kb` folder inside the user's `Hunt` folder. Check for them before doing anything else.

**Find the folder.** In the folder the user has connected, look for `Hunt/kb`. Match folder and file names case-insensitively (`Hunt`, `hunt`, and `HUNT` are the same). If the connected folder is itself the Hunt folder, `kb` sits at its top level. If no folder is connected, ask the user to connect the one that contains their Hunt folder, then run this check.

**Required items.** All six must be present:

1. The `kb` folder
2. `tahiti-is-a-magical-place.md`
3. `hunt-final-report-template.md`
4. `crowdstrike-query-primitives.md`
5. `crowdstrike-query-favorites.md`
6. `crowdstrike-query-playbook.md`

Verify by listing the folder's contents in this session. Don't rely on memory, an earlier conversation, or the user's description of what is there. A file that exists but is empty counts as missing.

**If anything is missing, stop.** Tell the user which items are missing and where you looked, ask them to restore the files and run the skill again, and end your turn. Stopping means all of the following:

- Don't read any kb files.
- Don't write queries or create hunt folders.
- Don't start the hunt or ask for the trigger.
- Don't offer to carry on from general SIEM knowledge, and don't recreate the missing files.

The reason for the hard stop: these files are the team's vetted way of working. The process file is how the hunt is run, the report template is how it is closed, and the three query files are the team's query conventions. A hunt run without them would be generic rather than the team's own, which defeats the purpose of the exercise and teaches operators the wrong patterns. A clear "can't proceed" is more useful than a hunt built on guesses.

Use a short message like this, giving the location relative to the connected folder (for example `Hunt/kb`) rather than a full system path:

```
I can't start the hunt. The knowledge base is incomplete.

Looked in: <kb folder location, or where you expected it>
Missing: <each missing item>

Restore what's missing and run the skill again.
```

If a file with a near-miss name is present (a different extension, a typo, a plural), mention it as a possible rename, but still stop. Guessing that it is the right file is the kind of assumption this gate exists to prevent.

Only when all six items are present, go on to Step 2.

## Step 2: Read the knowledge base

Read these files from the `kb` folder, in this order. Read each one in full. They are long, so read in sections rather than relying on the opening lines.

1. **`tahiti-is-a-magical-place.md`** is the hunt process: the TaHiTI method (Initiate, Hunt, Finalize). Once this skill's three steps are done, it governs everything.
2. **`crowdstrike-query-primitives.md`, `crowdstrike-query-favorites.md`, and `crowdstrike-query-playbook.md`** explain how to structure queries in CrowdStrike. When the process calls for a query, start from a favorite when one fits. Otherwise compose the query from primitives. Write new query logic only for the parts neither covers, and follow the playbook's standards when you do, including its guiding principle of writing for the human reading the query. Note in the query which favorite or primitive each block came from so the operator can find it again.
3. **`crowdstrike-hunt-lessons-learned.md` and `network-knowledge.md`** hold what has been learned about the user's environment.

Do not read `hunt-final-report-template.md` now. The gate only confirms it is there, and the process file says when to read it.

`crowdstrike-hunt-lessons-learned.md`, and `network-knowledge.md` are supporting material and are not part of the hard gate. If one of them is missing, tell the user which one, create an empty file, and continue without it.

Don't read the hunt subfolders (`hunt-01`, `hunt-02`, and so on) or other files in the Hunt folder unless the user points you to them or the process file tells you to. What matters from earlier hunts is already distilled into the lessons-learned file, and reading every past hunt costs time without adding much.

## Step 3: Say you're ready

Tell the user, briefly, that you're ready to walk through a structured hunt, and mention any supporting file that was missing. Then wait.

From here on, follow `tahiti-is-a-magical-place.md`. It says how the hunt opens, where its files go, how each turn runs, and how the hunt closes.

## The kb is read-only unless the user says otherwise

Do not update, rename, or delete any file in the `kb` folder without first getting the user's explicit permission. This holds for the whole hunt, including the Finalize phase.

When the hunt produces something worth keeping, such as a new favorite, a new primitive, a lesson learned, or a fact about the environment, propose the exact change and wait for a yes before making it. The kb is the team's vetted source of truth, and every change to it should be one the user has seen and agreed to.
