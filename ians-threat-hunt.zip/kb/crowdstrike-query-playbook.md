# CrowdStrike Query Playbook: Building FQL & CQL Queries Quickly and Accurately

*A consolidated, fact-checked reference for the consulting team supporting Wolfgang's security organization. It merges three source briefs into one practical playbook and adds a scoring rubric for building powerful queries fast.*

> **Guiding principle — write for the human at the terminal.** The goal is to be human-understandable and to increase human understanding and knowledge. Queries should be as readable as possible: a one-line statement of intent, clear field/alias names, multi-line layout, and comments that say *why*. Don't add fluff for fluff's sake — but where there's a trade-off, bias toward the person reading the query, not the machine running it.

---

## 0. The One Thing to Get Right First: FQL ≠ CQL

The single most expensive misunderstanding on this platform is treating CrowdStrike as having one query language. It has **two**, and they are not interchangeable.

```
                     +----------------------------------------+
                     |          CrowdStrike Platform          |
                     +----------------------------------------+
                                        |
              +-------------------------+-------------------------+
              |                                                   |
              v                                                   v
   +-----------------------+                         +-----------------------+
   |    SIEM Log Search     |                        |    API & Workflows    |
   |         (CQL)          |                        |        (FQL)          |
   +-----------------------+                         +-----------------------+
   | * Pipeline syntax,     |                        | * property:operator   |
   |   chained by pipes (|) |                        |   value expressions   |
   | * LogScale &           |                        | * Falcon REST APIs,   |
   |   Next-Gen SIEM        |                        |   Foundry, SOAR inputs|
   | * Search, dashboards,  |                        | * Filter & sort       |
   |   correlation rules    |                        |   metadata/records    |
   +-----------------------+                         +-----------------------+
```

**The rule of engagement to put at the top of your query standards:**

> **CQL** for SIEM search, hunting, dashboards, and correlation/detection content.
> **FQL** for Falcon API filtering, enrichment, automation, SOAR inputs, and Foundry collections.

CQL (CrowdStrike Query Language) is the pipe-based language used inside Falcon LogScale and Next-Gen SIEM; older material sometimes still calls it **LQL**. FQL (Falcon Query Language) is the property-operator-value filter/sort language used by Falcon REST API endpoints. Their operators, field names, valid timestamp properties, and even logical connectors differ. Teams that blur the two waste large amounts of time on avoidable trial-and-error, so stop using the generic phrase "FQL query" for everything.

---

## 1. Learning Plan — Get Productive in Four Hours

A focused ramp for the team. Each hour builds on the last.

| Hour | Focus | What to learn |
|------|-------|---------------|
| **1** | Architecture & language split | Internalize the FQL vs CQL distinction above. Read CrowdStrike's official FQL API reference and the LogScale/CQL syntax docs side by side so the difference is concrete, not abstract. |
| **2** | CQL pipeline mechanics | Pipelines (`\|`), implicit-AND filtering, dynamic field assignment (`:=`), aggregation (`groupBy()`, `stats()`), readability, and statement ordering (filter early, format late). |
| **3** | FQL filtering & data modeling | FQL `property:operator value` rules, strict data-type formatting, endpoint-specific filterable fields, plus the CrowdStrike Parsing Standard (CPS) and field aliasing that make a mixed environment queryable. |
| **4** | Acceleration & AI assist | Query Translation Agent (Splunk SPL → CQL), Charlotte AI for natural-language query generation, examples library, and the path from ad hoc hunt to saved search → dashboard → correlation rule. |

### Core references to open immediately

- CrowdStrike Falcon Query Language (FQL) — API filter syntax and operators
- CrowdStrike LogScale / Next-Gen SIEM CQL — syntax, operators, conditional evaluation
- "Statement Order for Better Queries" and query readability guidance
- CrowdStrike Parsing Standard (CPS) and field aliasing documentation
- Official examples library and "commonly-used query functions"
- Correlation rules and saved-search material
- Community: the CQL-Queries / CQL-Hub GitHub repos for real-world patterns

### Formal training (optional but recommended for scaling)

- **CrowdStrike University** LogScale (LOG-series) and Next-Gen SIEM (SIEM-series) tracks cover repository management, ingestion, parsing, advanced CQL, correlation rules, and investigation.
- **CCSE — CrowdStrike Certified SIEM Engineer** (exam CCSE-204): data ingestion, log parsing, CPS mapping, advanced CQL optimization. Recommends ~6 months of Next-Gen SIEM experience.
- **CFCP — CrowdStrike Certified Falcon Professional**: log analysis, alert investigation via the Incident Workbench, correlation rule management.

### What you actually need to know to write queries from scratch

Familiarity with: the FQL/CQL split; CQL pipeline structure and operators; FQL filter/sort syntax per endpoint; parser quality, CPS, and field aliasing; regex behavior and performance; saved searches, permissions, and correlation rules. On the domain side: Windows event/registry behavior, Active Directory authentication flows, and common exfiltration vectors — so queries map to real tradecraft.

---

## 2. FQL — Falcon Query Language (API Filtering)

FQL uses a declarative **`<property>:[operator]<value>`** structure for filtering, and **`<property>.<direction>`** for sorting. It evaluates metadata for API calls; it is *not* used for SIEM log search.

```
+-----------------------------------------------------------------+
|                      FQL Expression Anatomy                     |
+-----------------------------------------------------------------+
|  Property      |  Colon  |  Operator   |  Value                 |
|  (status)      |  ( : )  |  ( ! )      |  ( 'new' )             |
+-----------------------------------------------------------------+
```

### Properties

Alphanumeric/underscore, must start with a letter, treated as **lowercase**. Nested attributes use dots: `author.name`, `device_policies.mobile.policy_type`.

### Data-type formatting (strict)

| Type | Rule | Example |
|------|------|---------|
| **String** | Single quotes; wildcard `*` allowed inside the quotes for stemmed search | `hostname:'PROD*'` |
| **String (exact, case-sensitive)** | Wrap value in square brackets | `filename:['svchost.exe']` |
| **Boolean** | Lowercase, no quotes | `featured:true` |
| **Integer** | Plain, no quotes | `severity:>=70` |
| **Date** | ISO-8601 UTC, single-quoted | `last_seen:<='2024-06-01T00:00:00Z'` |

### Operators

`:` exact match (case-sensitive by default) · `!` not equal · `>` `<` `>=` `<=` comparisons · `~` text match (ignores case, spaces, punctuation) and `!~` its negation · `*` wildcard.

### Wildcards — two valid forms

- **Stemmed search** (most APIs): append `*` inside the quotes — `hostname:'server*'`.
- **Wildcard hint** (some APIs require it): place `*` *before* the opening quote to tell the preprocessor a wildcard is coming — `hostname:*'*server*'`. Some endpoints allow only one wildcard per property. If `hostname:'server*'` returns nothing unexpectedly, try the hint form.

### Combining conditions

`+` = AND · `,` = OR · `()` for grouping/precedence. **Maximum 20 properties per FQL statement** — split into multiple calls if you need more.

```text
# All hosts starting "g", plus any Linux host not starting "g2-"
(hostname:'g*'),(hostname:!'g2-*'+platform_name:'Linux')
```

### FQL starter pattern

```text
filter="<property>:'value'+<time_field>:>'2026-06-01T00:00:00Z'"
sort="<property>.desc"
```

> **Endpoint caveat:** filterable fields vary by API service collection. A property valid on one endpoint may return a 400 on another (a frequent real-world failure with incident timestamp fields). Validate filterable fields per endpoint before building automation.

---

## 3. CQL — CrowdStrike Query Language (SIEM Search)

CQL is a left-to-right **pipeline**: command statements separated by `|`, each passing data to the next. Build complex queries by chaining filtering → transformation → aggregation → formatting.

```
Tag/repo filter  →  field filters  →  dynamic fields (:=)  →  aggregation (groupBy/stats)  →  format (table/sort/timeChart)
```

### Design principle: filter early, format late

CrowdStrike's own guidance: **narrow the time range first, filter on tagged fields, then filter remaining field values, and only reduce/format/aggregate after the dataset is small.** In Next-Gen SIEM's index-free architecture, leading with tag filters (`#repo`, `#type`, `#Vendor`) is what keeps searches fast. High-cardinality `groupBy()` / `stats()` can generate too many rows and even cause query cancellation, so aggregate on a reduced set.

### CQL starter pattern

```cql
// Use case: <what you are trying to prove or disprove>
#repo=<repository> #type=<type>          // tag filters first
<high_selectivity_field>=<value>          // earliest high-value filter
| <secondary_field>=<value>
| <optional extraction / normalization>
| <optional lookup or field alias>
| <projection or aggregation>             // select/table/groupBy/timeChart
| <sort or timechart>
```

Multi-line formatting and `//` comments are official readability recommendations — make them mandatory in shared content.

---

## 4. FQL vs CQL — Quick Syntax Reference

| Feature | FQL (API) | CQL (SIEM) |
|---|---|---|
| **Domain** | REST APIs, Foundry collections, SOAR inputs | NG-SIEM search, dashboards, correlation rules |
| **Structure** | `property:operator value` | Pipeline chained by `\|` |
| **Logical AND** | `+` | Implicit (space) or explicit `AND` |
| **Logical OR** | `,` | Explicit `OR` (case-sensitive) |
| **Field assignment** | not supported | `:=` (e.g., `new := field`) |
| **String match** | `:` exact, `~` text match | `=` equals, `like`, regex `/.../` |
| **Numeric compare** | `>`, `<=`, etc. | `statuscode >= 400` |
| **Aggregation** | downstream/API only | native `groupBy()`, `stats()`, `timeChart()` |
| **Exact case-sensitive string** | `['VALUE']` | regex / explicit match |

> **Precedence gotcha (CQL only):** unlike most languages, **`OR` binds *more tightly* than `AND`** in CQL. Always use parentheses around logical groups, and prefer `|` over chained `AND` to avoid surprises.

---

## 5. Getting to Know Your Environment

Before you write a single hunt, find out what's actually in your tenant. Detection content built on *assumed* field values, platform names, or repositories breaks silently — a filter that matches nothing returns a false zero, not an error (Pitfall #13). The fastest way to ground a query in reality is to **enumerate** the field you're about to filter on. The pattern is always the same: scope with tag filters, then `groupBy()` the field with a count so you see both the value set **and** the relative volume.

### Reusable pattern — enumerate a field's distinct values

```cql
#repo=<repository>
| groupBy(<field>, function=count(as=event_count))
| sort(event_count, order=desc)
```

Swap `<field>` for whatever you need to discover: platforms, event types, repos, sensor versions, coded enums (Pitfall #16). Reading *which values appear and which never do* is often as informative as the counts themselves.

### Discovery 1 — What platforms are reporting?

```cql
#repo=base_sensor
| groupBy(#event_platform, function=count(as=event_count))
| sort(event_count, order=desc)
```

**Results (reference tenant, descending volume):**

| event_platform | Meaning |
|---|---|
| `Win` | Windows (standard sensor short code) |
| `Lin` | Linux |
| `PubC` | Public cloud telemetry |
| `Windows` | Windows — **non-standard label from a different source/parser** |

**Finding:** Windows appears under **two different labels** — `Win` *and* `Windows`. That's a normalization gap, not a quirk to wave off: any hunt that filters `event_platform=Win` will silently miss every event tagged `Windows`, and vice versa. This is exactly the failure Pitfall #7 (querying raw vendor fields instead of normalized ones) warns about. Two practical takeaways:

- When filtering platform, account for both forms until the source is normalized — e.g. `event_platform=/^Win/i` or `in(field=event_platform, values=["Win","Windows"])`.
- Treat the `Windows` and `PubC` rows as leads: trace which repo/parser emits them so the inconsistency can be fixed once, upstream (via CPS / field aliasing), rather than worked around in every query. `PubC` also confirms cloud telemetry is flowing into `base_sensor` — verify that source before assuming the repo is endpoint-only.

### Discovery 2 — What telemetry does each platform emit?

Once you know your platforms, enumerate the **event types** each one produces. This is the single most useful piece of environment recon: it tells you what you can actually hunt on before you waste time designing a query around an event the sensor never sends.

```cql
#repo=base_sensor event_platform=Win
| groupBy(#event_simpleName, function=count())
| sort(_count, order=desc)
```

Repeat per platform (`event_platform=Lin`, `PubC`, and the non-standard `Windows`) — the value set differs on each, which is exactly why you enumerate rather than assume.

**Results — `Win` (reference tenant):** 200 distinct `event_simpleName` values. The full list, in descending-volume order, is saved alongside this playbook in `event_simplenames_win.csv`.

> **Capture the counts next time.** This export carried only the names, so we have the *volume ranking* but not absolute counts. Re-run keeping the `_count` column (`function=count(as=event_count)`) to size cost/noise — the handful of highest-volume events (`ProcessRollup2`, `EndOfProcess`, `NetworkConnectIP4`, `DnsRequest`, `ClassifiedModuleLoad`…) drive most of your storage and search cost and are also your highest-value hunting telemetry.

**The 200 Win event types, grouped by what they let you hunt:**

- **Process & execution:** `ProcessRollup2`, `SyntheticProcessRollup2`, `EndOfProcess`, `ProcessAncestryInformation`, `MsiTransactionExecuted`, `BITSJobCreated`
- **Module load & code injection:** `ClassifiedModuleLoad`, `ModuleDetectInfo`, `InjectedThread`, `ProcessInjection`, `DllInjection`, `ReflectiveDotnetModuleLoad`
- **Network:** `NetworkConnectIP4`, `NetworkConnectIP6`, `NetworkReceiveAcceptIP4`, `NetworkReceiveAcceptIP6`, `NetworkListenIP4`, `NetworkListenIP6`, `NetworkCloseIP4`, `RawBindIP4`, `PromiscuousBindIP4`, `NeighborListIP4`, `NeighborListIP6`, `LocalIpAddressIP4`, `LocalIpAddressRemovedIP4`, `HttpVisibilityStatus`
- **DNS:** `DnsRequest`, `SuspiciousDnsRequest`
- **File written (by type):** executables/scripts — `NewExecutableWritten`, `NewExecutableRenamed`, `ExecutableDeleted`, `PeFileWritten`, `MotwWritten`, `NewScriptWritten`, `ScriptFileWrittenInfo`, `PythonFileWritten`, `ELFFileWritten`, `JarFileWritten`, `MsiFileWritten`, `RegistryHiveFileWritten`, `DmpFileWritten`, `LnkFileWritten`, `GenericFileWritten`, `ImgExtensionFileWritten`, `EmailFileWritten`, `EmailArchiveFileWritten`; archives — `ZipFileWritten`, `GzipFileWritten`, `CabFileWritten`, `SevenZipFileWritten`, `XzFileWritten`, `ZstdFileWritten`; docs/images — `PdfFileWritten`, `RtfFileWritten`, `OoxmlFileWritten`, `MSDocxFileWritten`, `MSXlsxFileWritten`, `MSPptxFileWritten`, `OleFileWritten`, `EseFileWritten`, `PngFileWritten`, `JpegFileWritten`, `GifFileWritten`, `TiffFileWritten`, `BmpFileWritten`, `CrxFileWritten`
- **File operations:** `FileCreateInfo`, `FileOpenInfo`, `FileDeleteInfo`, `FileRenameInfo`, `DirectoryCreate`, `RansomwareOpenFile`, `SuspiciousCreateSymbolicLink`, `FileSystemOperationDetectInfo`, `FileIntegrityMonitorRuleMatched`, `FsPostOpenSnapshotFile`
- **Registry:** `RegCrowdstrikeValueUpdate`, `RegGenericValueUpdate`, `RegSystemConfigValueUpdate`, `RegSystemConfigKeyUpdate`, `AsepValueUpdate`, `AsepKeyUpdate`, `SuspiciousRegAsepUpdate`, `RegistryOperationDetectInfo`
- **Services:** `ServiceStarted`, `ServiceStopped`, `CreateService`, `ModifyServiceBinary`, `KernelServiceStarted`, `HostedServiceStarted`, `HostedServiceStopped`, `ServicesStatusInfo`
- **Scheduled tasks:** `ScheduledTaskRegistered`, `ScheduledTaskModified`, `ScheduledTaskDeleted`
- **Authentication & logon:** `UserLogon`, `UserLogoff`, `UserLogonFailed`, `UserLogonFailed2`, `UserIdentity`, `IoSessionLoggedOn`, `IoSessionConnected`, `LogonBehaviorCompositionDetectInfo`, `LocalWindowsUserUpdate`
- **Active Directory / Identity Protection:** `ActiveDirectoryAuthentication`, `ActiveDirectoryAuthenticationFailure`, `ActiveDirectoryInteractiveDomainLogon`, `ActiveDirectoryIncomingLdapSearchRequest`, `ActiveDirectoryServiceAccessRequest`, `ActiveDirectoryServiceAccessRequestFailure`, `ActiveDirectoryIncomingDceRpcRequest`, `ActiveDirectoryAccountPasswordUpdate`, `IdpDcPerfReport`, `IdpCloudHealthCheck`, `IdpPolicyAccessRuleMatch`
- **Credential access & handle abuse:** `LsassHandleFromUnsignedModule`, `SAMHashDumpFromUnsignedModule`, `SuspiciousPrivilegedProcessHandle`, `FalconProcessHandleOpDetectInfo`, `TokenImpersonated`, `SensitiveWmiQuery`
- **Driver / kernel:** `DriverLoad`, `DriverPreventionStatus`
- **Firewall & network tampering:** `FirewallSetRule`, `FirewallDeleteRule`, `FirewallChangeOption`, `WfpFilterTamperingFilterAdded`
- **Script control (AMSI / .NET):** `ScriptControlScanTelemetry`, `ScriptControlDetectInfo`, `ScriptControlDotNetMetadata`, `ScriptControlErrorEvent`
- **ETW / WMI / SMB:** `WmiProviderRegistrationEtw`, `EtwComponentResponse`, `ScreenshotTakenEtw`, `SmbClientShareOpenedEtw`, `SmbClientShareClosedEtw`, `SmbServerShareOpenedEtw`
- **Device control (USB / Bluetooth):** `DcUsbDeviceConnected`, `DcUsbDeviceDisconnected`, `DcUsbEndpointDescriptor`, `DcUsbInterfaceDescriptor`, `DcUsbConfigurationDescriptor`, `DcUsbHIDDescriptor`, `DcBluetoothDeviceConnected`, `DcBluetoothDeviceDisconnected`, `DcBluetoothDeviceProperties`, `DcOnline`, `DcStatus`
- **Volumes & snapshots:** `MountedVolume`, `FsVolumeMounted`, `FsVolumeUnmounted`, `SnapshotVolumeMounted`, `VolumeSnapshotCreated`, `DiskCapacity`
- **Host inventory & posture:** `InstalledApplication`, `InstalledUpdates`, `InstalledBrowserExtension`, `OsVersionInfo`, `HostInfo`, `AdditionalHostInfo`, `SystemCapacity`, `CurrentSystemTags`, `ImageHash`, `PeVersionInfo`, `UserFontLoad`
- **Vulnerability (Spotlight):** `SpotlightEntitySystemState`, `SpotlightEntityBatch`, `SpotlightEntityBatchHeader`
- **Firmware / hardware / TPM:** `FirmwareAnalysisStatus`, `FirmwareAnalysisErrorEvent`, `FirmwareAnalysisHardwareData`, `FirmwareImageAnalyzed`, `TcgPcrInfo`
- **On-demand scan (ODS):** `OdsStarted`, `OdsStatus`, `OdsActionStatus`
- **Sensor health, config & data transport:** `SensorHeartbeat`, `FalconServiceStatus`, `ConfigStateUpdate`, `ResourceUtilization`, `BillingInfo`, `AgentConnect`, `AgentOnline`, `ChannelActive`, `SensorSettingsUpdate`, `SensorAntiTamperState`, `SensorSelfDiagnosticTelemetry`, `MemoryScanEnabled`, `PtActivationStatus`, `LightningUnresponsiveStatus`, `ZeroTrustHostAssessment`, `LFODownloadConfirmation`, `LfoUploadStart`, `LfoUploadDataComplete`, `DeliverLocalFXToCloud`, `ErrorEvent`, `UmppaErrorEvent`
- **Detection metadata:** `AssociateIndicator`, `AssociateTreeIdWithRoot`, `DetectionExcluded`

**Finding:** the highest-value hunting families (process, module/injection, network, file-write, registry, services, scheduled tasks, AD/identity, credential access) are all well-represented on `Win` — so the use cases in §6 are supported by real telemetry here. The presence of dedicated **effect events** (`FirewallChangeOption`, `SAMHashDumpFromUnsignedModule`, `LsassHandleFromUnsignedModule`, `TokenImpersonated`) reinforces Use Case 11's rule: *prefer the native effect event over command-line reconstruction whenever one exists.* When you enumerate `Lin`, `PubC`, and `Windows`, expect noticeably smaller and different sets — note which families vanish, because that's where a Win-derived hunt will silently return nothing on those platforms.

**Results — `Lin` (reference tenant):** 46 distinct `event_simpleName` values — less than a quarter of the Win surface. Full list saved alongside this playbook in `event_simplenames_lin.csv`. (This export, too, carried only the names despite the `count(as=event_count)` query — the console's CSV export appears to drop the measure column, so confirm "include all columns" in the export dialog if you need counts.)

**The 46 Linux event types, grouped by what they let you hunt:**

- **Process & execution:** `ProcessRollup2`, `ProcessRollup2Stats`, `SyntheticProcessRollup2`, `ProcessAncestryInformation`, `ProcessSignal`, `TerminateProcess`
- **Pseudo-terminal (interactive shell):** `PtyAttached`, `PtyDetached`
- **Network:** `NetworkConnectIP4`, `NetworkConnectIP6`, `NetworkReceiveAcceptIP4`, `NetworkListenIP4`, `NetworkListenIP6`, `NeighborListIP4`, `LocalIpAddressIP4`, `CreateSocket`, `NetworkLinkConfigGetAddress`, `NetworkLinkConfigGetLink`
- **DNS:** `DnsRequest`
- **File written:** `ELFFileWritten`, `NewExecutableWritten`, `GzipFileWritten`, `XzFileWritten`, `ZipFileWritten`, `EmailFileWritten`
- **File & environment access:** `CriticalFileAccessed`, `CriticalEnvironmentVariableChanged`
- **Services (systemd):** `SystemdServiceCreated`, `SystemdServiceDeleted`
- **Authentication & logon:** `UserLogon`, `UserLogoff`, `UserIdentity`
- **Kernel / eBPF:** `BPFCommandIssued`
- **Containers:** `OciContainerTelemetry`
- **Vulnerability (Spotlight):** `SpotlightEntitySystemState`
- **Host inventory & capacity:** `CurrentSystemTags`, `SystemCapacity`, `DiskCapacity`, `DiskUtilization`, `ResourceUtilization`
- **Sensor health, config & transport:** `SensorHeartbeat`, `ConfigStateUpdate`, `DeliverLocalFXToCloud`, `DeliverRulesEngineResultsToCloud`, `LFODownloadConfirmation`, `ErrorEvent`

**Finding — Linux is a different telemetry world, not a smaller Windows.** Two things stand out:

- **Linux-native families that don't exist on Windows:** pseudo-terminal session tracking (`PtyAttached`/`PtyDetached` — the closest thing to "interactive shell" visibility), eBPF (`BPFCommandIssued`), containers (`OciContainerTelemetry`), `systemd` service lifecycle (`SystemdServiceCreated`/`Deleted`), plus `ProcessSignal`, `TerminateProcess`, `CreateSocket`, `CriticalFileAccessed`, and `CriticalEnvironmentVariableChanged`. Linux hunts should be *built around these*, not ported from Windows.
- **Whole Windows hunting families are simply absent:** module load / code injection, the registry (n/a by design), scheduled tasks, AD / Identity Protection, credential-access handle events (`LsassHandleFromUnsignedModule`, `SAMHashDumpFromUnsignedModule`, `TokenImpersonated`), device control (USB/Bluetooth), firewall, script control, ETW/WMI/SMB, volume/snapshot, firmware/TPM, ODS, and nearly all the file-type-written variants (Linux keeps only `ELF`/archive/email forms). Granular file ops collapse from ten Win events to a single `CriticalFileAccessed`.

The takeaway for the team: a `#event_simpleName=ProcessRollup2` or network-based hunt translates cleanly to Linux (those events exist on both), but anything keyed to registry, scheduled tasks, AD, or `*HandleFromUnsignedModule` returns a **false zero** on Linux — the field matches nothing because the event was never emitted, not because the activity is absent. Pick Linux-native equivalents (`systemd` for persistence, `Pty`/`ProcessSignal` for interactive activity, `BPFCommandIssued` for kernel tampering) instead.

### Discovery 3 — What Tactics & Techniques are present?

Knowing which MITRE ATT&CK tactics and techniques actually appear in your data tells you where your detection coverage is concentrated — and where it's thin. Enumerate the pair with counts:

```cql
#repo=base_sensor
| groupBy([Tactic, Technique], function=count(as=event_count))
| sort(event_count, order=desc)
```

**Results (reference tenant):** 81 distinct Tactic/Technique pairs across **18 tactics**. Full list with counts saved alongside this playbook in `tactics_techniques.csv`.

**Finding 1 — most of `base_sensor` has no tactic at all (the blank bucket).** The single largest group by far is **blank Tactic *and* blank Technique** — the majority of all records. That's expected: `base_sensor` is overwhelmingly raw telemetry (process, network, file, registry events), and Tactic/Technique only populate on *detection/OverWatch/ML-tagged* records. **Practical consequence:** any `groupBy(Tactic …)` over `base_sensor` will be dominated by an empty bucket. Always prune it first when ranking detections:

```cql
#repo=base_sensor
| Tactic!=""                                    // drop raw, un-tagged telemetry
| groupBy([Tactic, Technique], function=count(as=event_count))
| sort(event_count, order=desc)
```

**Finding 2 — the tactic labels are not pure MITRE.** Six of the 18 tactics are **CrowdStrike-specific buckets, not standard ATT&CK Enterprise tactics**: `Falcon Overwatch`, `Custom Intelligence`, `Machine Learning`, `Malware`, `Post-Exploit`, and `Exploit`. Don't assume a query filtering on the 14 canonical MITRE tactics will catch everything — the IOA work earlier keys on exactly one of these (`Tactic="Custom Intelligence"`).

**Tactic rollup (detections only, blank excluded), in descending volume:**

| Tactic | Description |
|---|---|
| Defense Evasion | Dominant — `Process Injection`, `Impair Defenses`, masquerading, registry modification |
| Initial Access | Almost entirely `Spearphishing Attachment` |
| Discovery | `System Owner/User Discovery`, file/remote-system discovery |
| Persistence | Run keys, WMI event subscription, web shells |
| Execution | Command interpreter, PowerShell, malicious file |
| Falcon OverWatch | *CS-specific* — managed-hunting `Malicious Activity` |
| Privilege Escalation | UAC bypass, access-token manipulation |
| Credential Access | OS credential dumping, password-filter DLL |
| Lateral Movement | SMB/admin shares, remote services, RDP |
| Command and Control | App-layer protocol, remote-access tools |
| Impact | Data encrypted for impact, disk wipe |
| Malware | *CS-specific* — malicious file, PUP, adware |
| Collection | Data staged, automated collection |
| Machine Learning | *CS-specific* — cloud/sensor-based ML |
| Custom Intelligence | *CS-specific* — `Indicator of Attack` (your IOA bucket) |
| Exfiltration | Exfiltration to cloud storage |
| Post-Exploit | *CS-specific* |
| Exploit | *CS-specific* — exploit mitigation |

**Finding 3 — the same technique appears under more than one tactic**, so a technique-only filter can split or double-count. `Malicious File` shows up under both `Execution` and `Malware`; `Valid Accounts` under `Persistence` and `Privilege Escalation`; `Scheduled Task/Job` under `Execution` and `Persistence`. When ranking by technique, group by the **`[Tactic, Technique]` pair** (as above) rather than `Technique` alone, or you'll merge two distinct detection contexts into one row.

---

## 6. Translating Use Cases into Production Queries

### CQL — Reusable pattern: activity timespan per entity (`first_seen` / `last_seen`)

Almost every hunt eventually asks not just *how many* but *over what span* — when an entity (a source IP, user, host/`aid`, command line, USB device…) first and last appeared in the window. The idiom is to fold `min()` and `max()` of the event timestamp into the same `groupBy()` you're already running:

```cql
| groupBy([<entity fields>], function=[
      count(as=events),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)
| sort(last_seen, order=desc, limit=1000)
```

`min(@timestamp)` is the first sighting in the window; `max(@timestamp)` is the most recent. Swap the grouping key for whatever entity you're profiling — `client.ip` (spray sources), `[ComputerName, UserName, CommandLine]` (who ran what, when), `[DeviceSerialNumber, aid]` (where a USB device roamed). Pair it with `count()` and `collect([...])` to carry supporting context (usernames, reasons, logon types) into the same row.

**Sort numeric, humanize last.** Keep the sort on the raw numeric timestamp, then convert to readable dates as the *final* statements so the sort never breaks:

```cql
| sort(first_seen, order=asc, limit=1000)
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
```

Switch `timezone` to `"America/Detroit"` for local Eastern; flip `order=asc`↔`desc` for chronological vs most-recent-first.

**Process-time variant.** When you care about *process start* rather than event ingest time, use `stats()` with `earliest()/latest()` on the process-start field instead (see Use Case 2): `earliest(ProcessStartTime_decimal) as first_execution_time, latest(ProcessStartTime_decimal) as last_execution_time`.

> **Caveat — `first_seen` within a window ≠ genuinely new.** A 7-day `min(@timestamp)` only means "first seen in the last 7 days," not "new to the environment." For true novelty (a new app, account, or device), hunt lifecycle/creation events or compare against a longer baseline rather than trusting `first_seen` from a short window.

### CQL — Use Case 1: AD interactive / RDP logon-failure brute force

Track failed Windows interactive and RDP logons across endpoints, exclude known service accounts via a lookup, and surface users hitting many distinct hosts.

```cql
// Scope to base sensor Windows telemetry
#repo=base_sensor #type=falcon-raw-data event_platform="Win"
// Failed interactive / RDP authentication events
| #event_simpleName=UserLogonFailed OR event_simpleName=UserLogonFailed2
| ComputerName=*
| UserName=*
// Drop expected service accounts via glob lookup table
| !match(file="ignore_username_table", field=UserName, column=ignoreUserName, mode=glob)
// Normalize case for clean grouping
| lower(field=UserName, as=UserName)
// Aggregate distinct targeted hosts per user
| groupBy(UserName, function=[
    count(aid, distinct=true, as=host_distinct_count),
    collect([aid, ComputerName], limit=5)
  ], limit=max)
// Keep users hitting 5+ distinct hosts
| host_distinct_count >= 5
| sort(host_distinct_count, order=desc, limit=1000)
```

*Why it works:* repo/tag filter cuts data volume first; lookup prunes expected noise; `groupBy` reveals high-fan-out failures characteristic of credential brute forcing.

### CQL — Use Case 2: LOLBin clustering (Qbot-style discovery)

Detect a single parent process spawning many living-off-the-land binaries in quick succession.

```cql
#repo=base_sensor event_platform=win #event_simpleName=ProcessRollup2
// Discovery-phase binaries
| FileName IN (whoami.exe, arp.exe, cmd.exe, net.exe, net1.exe, ipconfig.exe, route.exe, netstat.exe, nslookup.exe)
| stats(
    dc(FileName) as unique_binary_count,
    earliest(ProcessStartTime_decimal) as first_execution_time,
    latest(ProcessStartTime_decimal) as last_execution_time,
    values(FileName) as executed_binaries,
    values(CommandLine) as execution_arguments
    by cid, aid, ComputerName, ParentBaseFileName, ParentProcessId_decimal)
// Single parent running 4+ distinct utilities
| test(unique_binary_count >= 4)
```

*Why it works:* grouping by the **parent process** turns isolated executions into a behavioral cluster — far more indicative of an automated discovery script than any single binary.

### CQL — Use Case 3: Data-exfiltration egress monitoring

Flag command lines referencing cloud-storage / transfer utilities.

```cql
#repo=base_sensor #event_simpleName=ProcessRollup*
| CommandLine=/ (copy|webapp|copyto|sync) /i
| in(field=CommandLine, values=["*dropbox:*", "*remote:*", "*mega:*", "*yandex:*", "*ftp:*"])
| !in(field=CommandLine, values=["*aws*"])    // prune known-good admin tooling
| table([@timestamp, ComputerName, UserName, CommandLine], limit=20000)
```

*Why it works:* case-insensitive regex plus `in()` catches sync/copy verbs against external targets; a negative filter removes expected administrative traffic.

### CQL — Use Case 4: Detections by ATT&CK tactic (triage / exec reporting)

```cql
metadata.eventType=DetectionSummaryEvent
| event.Tactic=*
| groupBy(event.Tactic, function=count(as=hits))
| sort(hits, order=desc)
```

### CQL — Use Case 5: Investigate suspicious PowerShell detections

```cql
metadata.eventType=DetectionSummaryEvent
| event.DetectName=/power.?shell/i
| select([@timestamp, event.ComputerName, event.UserName, event.DetectName, event.Technique, event.Objective])
| sort("@timestamp")
```

### CQL — Use Case 6: IOC hunt (known-bad IP), then scope impact

```cql
case {
  tx_hosts[0] = "<MALICIOUS_IP>" | knownThreat := true;
  *                              | knownThreat := false
}
| knownThreat=true
| groupBy(rx_hosts[0], function=count(as=connections))
| sort(connections, order=desc)
```

*Reusable for risky domains, file hashes, usernames, or destination ports.*

### CQL — Use Case 7: Baseline / anomaly over time

```cql
<base_filter>
| timeChart(span=10m, function=count())
```

Add series by category when you need per-entity trends:

```cql
<base_filter>
| timeChart(span=1h, function=count(), series=<category_field>)
```

### CQL — Use Case 8: Failed logins by user (with optional grand total)

```cql
<outcome_field>="failure"
| groupBy(<user_field>, function=count(as="failed_attempts"))
| sort(failed_attempts, order=desc)
```

```cql
<outcome_field>="failure"
| groupBy(<user_field>, function=count(as="failed_attempts"))
| appendAggregation({ sum(failed_attempts, as="failed_attempts") | <user_field>:="All Users" })
```

*Keep the functional pattern stable and swap in normalized fields (`auth_result`, `event.outcome`, vendor-specific) via CPS / field aliasing.*

### CQL — Use Case 11: Firewall tampering via native effect event (T1562.004)

Detect a Windows firewall profile being turned off using CrowdStrike's dedicated `FirewallChangeOption` event instead of reconstructing intent from process command lines.

```cql
// Prove or disprove: a host firewall profile was disabled (T1562.004)
#repo=base_sensor event_platform=Win #event_simpleName=FirewallChangeOption
| FirewallOption=EnableFirewall
| FirewallOptionNumericValue=0          // 0 = disabled, 1 = enabled
// True volume — do NOT count with table(limit=N)
| groupBy([FirewallProfile, ComputerName], function=count(as=disables))
| sort(disables, order=desc)
```

*Why it works:* `FirewallChangeOption` records the **effect** — the setting actually changed — regardless of how it was driven: `netsh`, the `Set-NetFirewallProfile` cmdlet run interactively, the GUI, or an MMC snap-in. A `ProcessRollup2` CommandLine regex only fires when the *tool* was invoked with the tell-tale text on its command line, so interactive-session and GUI changes are invisible to it. **Prefer the native effect / state-change event whenever one exists**, and fall back to command-line reconstruction only when there isn't one.

**Field notes (verify per tenant):**
- `FirewallOption=EnableFirewall` + `FirewallOptionNumericValue=0` is the disable; `=1` is a re-enable. A quick disable→enable bracket on the same host is the fingerprint of a config push applying settings.
- `FirewallProfile` is a **coded** field whose legend is tenant-specific. The reference tenant uses the simple enum **1=Domain, 2=Private, 3=Public** — confirmed empirically (a `3` exists and `4` never appears, which rules out the Windows `1/2/4` bitmask). Confirm yours before trusting labels.
- High-volume disables are usually **systemic** (GPO, Intune/MDM, a security agent, or imaging/onboarding), not isolated attacks. Hunt anomalies against that baseline — a host disabling far more than its peers, or one whose `ContextProcessId` resolves to `powershell.exe`/`cmd.exe` — rather than alerting on raw occurrences.

### FQL — Use Case 9: Spotlight critical-vuln profiling

New, unmitigated critical vulnerabilities on Windows (Spotlight API):

```fql
platform_name:'windows'+status:'new'+severity:>=70
```

### FQL — Use Case 10: Host lookup with sort

```text
filter="platform_name:'windows'+hostname:*'app-*'+last_seen:>'2026-06-01T00:00:00Z'"
sort="hostname.asc"
```

Nested child properties use dotted notation: `filter="device_policies.mobile.policy_type:'mobile'"`. Confirm the field is filterable on *that* endpoint first.

---

## 7. Common Pitfalls and Anti-Patterns

1. **Syntax conflation (the #1 error).** Using FQL operators (`+`, `,`) inside CQL, or pipes (`|`) inside FQL fields, causes immediate failures. Enforce the CQL-for-SIEM / FQL-for-API rule.
2. **CQL precedence surprise.** `OR` binds tighter than `AND` in CQL. Use explicit parentheses and prefer `|` over chained `AND`.
3. **Inefficient scoping / missing tags.** Querying without `#repo`/`#type` tags forces a full scan → slow searches, timeouts, wasted resources. Always lead with tag filters; do renames and aggregation later.
4. **Case-statement malformation** (common with AI-generated CQL). Each branch ends with `;`, assignments use `:=`, and numeric/comparison conditions should be wrapped in `test()`. Include a default `*` branch.
   ```cql
   // WRONG
   case { score >= 75 | alert_tier = "Critical";
          score >= 50 | alert_tier = "Moderate" }
   // RIGHT
   case { test(score >= 75) | alert_tier := "Critical";
          test(score >= 50) | alert_tier := "Moderate";
          *               | alert_tier := "Low" }
   ```
   *(Simple field filters like `src="frontend"` work directly without `test()`; reserve `test()` for arithmetic/comparison expressions.)*
5. **Regex misuse.** `/regex/` across all fields is slow — prefer field-specific regex. LogScale uses a JitRex/RE2J engine (not a clone of every third-party tool), and backslashes often need double-escaping. Test patterns *in LogScale* before operationalizing.
6. **Poor grouping design.** High-cardinality `groupBy()`/`stats()` makes too many rows and can cancel the query. If output duplicates hosts/users, check your **grouping keys** before the sort.
7. **Querying raw vendor fields instead of normalized ones.** Skipping CPS/field aliasing means rewriting the same logic per data source. Normalize once; reuse the pattern everywhere.
8. **Assuming FQL properties are universal.** Filterable fields vary by API collection; validate per endpoint (even valid-looking date fields can 400).
9. **SOAR schema rigidity.** Falcon Fusion SOAR auto-generates a strict JSON validation schema from initial test results; later events with different fields fail validation. Disable *"Automatically generate schema and enforce schema validation"* and handle dynamic payloads with CEL.
10. **FQL/CQL string anchoring & quoting.** Forgetting quotes around strings/dates breaks FQL. Text filters may be anchored — use explicit wildcards (`*value*`) or regex for partial matches.
11. **Line-for-line Splunk/KQL translation.** Don't token-swap SPL into CQL. Restate the use case, map normalized fields, then rebuild with native CQL patterns (`groupBy`, `case`, `select`, `timeChart`, `regex`). Use the Query Translation Agent as a starting draft, not a final answer.
12. **Treating parser hygiene as optional.** Deprecated parsers degrade detection coverage even when ingestion still "works." Query quality is downstream of parser quality.
13. **Dropping the `#` on tagged fields.** In many tenants `event_simpleName` is ingested as a **tagged field** (`#event_simpleName`), in the same family as `#repo`, `#type`, and `#Vendor`. Referencing it without the hash (`event_simpleName=ProcessRollup2`) silently points at a non-existent field — filters match nothing and `groupBy()` returns "no available fields," producing a *false zero* rather than an error. Confirm the exact field name (including any leading `#`) against a raw event before building, and reference it identically everywhere. Whether a field is tagged varies by tenant/parser, so don't assume.
14. **Treating `table(..., limit=N)` as a count — and missing truncation.** Projection statements cap rows. If an export returns *exactly* the limit (e.g., 20,000), assume it's **truncated** and the true volume is unknown; never size a population from a capped table. Use `count()` / `groupBy(... function=count())` for real totals, and reserve `table()` for inspecting sample rows.
15. **The sorted-table-top illusion.** The first N rows of a time-sorted (or otherwise sorted) capped table can masquerade as a tight cluster — "15 hosts disabling in a 7-minute window" — when they're merely the newest slice of a large, ongoing baseline. Aggregate (`groupBy`, `timeChart`) to see the real distribution before inferring incident shape from the top of a table.
16. **Trusting coded/enumerated field labels without confirming the legend.** Numeric-coded fields (firewall profiles, severities, status codes) can use different encodings per tenant/parser — e.g., a bitmask (`1/2/4`) versus a simple enum (`1/2/3`). Enumerate the actual value set with `groupBy(<field>, function=count())` and reason from which values appear *and which never do* before mapping numbers to names.
17. **Args-only command lines break prefix-anchored regexes.** This tenant logs some `cmd.exe` command lines with the full image path (`"C:\WINDOWS\…\cmd.exe" …`) and others **args-only** (`/k echo {GUID}`, `/c finger …`). A known-good exclusion anchored on `^"*\S*cmd\.exe"*` silently matches **nothing** on the args-only form — a 999/1000 false-zero flood until the prefix is made optional: `^("*\S*cmd\.exe"*\s+)?…`. A distinct false-zero cause from #13: there the *field name* is wrong; here the *value shape* is assumed.
18. **`table()` exports `@timestamp` as epoch milliseconds.** Project it raw and you get `1771596847000`, not a date — slice or `groupBy` on that and your buckets are meaningless. Always `formatTime()` the field (or convert on export) before any date analysis. Sort on the numeric value first, humanize last (see the `first_seen`/`last_seen` pattern in §6).
19. **Function calls don't work in filter expressions.** `in()` and friends are functions: legal as standalone pipe statements (`| in(field=FileName, values=[...])`), illegal inside a parenthesized filter expression — `| (in(...) OR CommandLine=/x/)` throws `FunctionCallsNotSupportedInFilterExpressions` plus a cascade of `ExpectedExpression` errors. For set-membership inside an OR group, use an anchored case-insensitive regex alternation instead: `FileName=/^(wscript|cscript|mshta|hh)\.exe$/i`. (HUNT-15 Q06.)
20. **Filename regexes miss 8.3 short names.** Windows can reference `new 25.js` as `NEW25~1.JS`; a long-name regex (`/new 25\.js/i`) matches nothing on such a command line — a false zero exactly where deliberate evasion lives. When proving "file never executed," add a short-name clause (`CommandLine=/NEW25~1/i`) or derive the 8.3 form of the target name. Same value-shape family as #17. (HUNT-15 Q06.)
21. **An "authoritative" effect event that never fires manufactures confident false negatives.** Use Case 11 says prefer the native effect event over command-line reconstruction — sound advice with a hard corollary: **prove the event fires for a known-true case before you trust its silence.** `PromiscuousBindIP4` looks like the definitive answer to "is anyone sniffing?" and is **blind to npcap**, which sets promiscuous mode at the NDIS driver layer while the event is winsock/`SIO_RCVALL`-shaped. HUNT-16: 160 confirmed `dumpcap -w` runs and dozens of live Wireshark captures on domain controllers → **zero** promiscuous-bind events; the only promiscuous binder fleet-wide is `svchost.exe` (~5,900 hosts, OS baseline). A distinct false-zero cause from #13 (wrong field name) and #17 (wrong value shape): here the field and value are *correct* and the **sensor simply never observes the behavior at that layer**. Same trap: pcap writes never emit `*FileWritten`. Ask "what layer does this event actually watch, and does my technique touch that layer?"
22. **Some event families identify their actor only by PID.** `PromiscuousBindIP4`, `RawBindIP4`, and the `*FileWritten` families carry `ContextProcessId` but **no** `ContextBaseFileName`/`ImageFileName`/`UserName` in this tenant. Because empty columns silently vanish (gotcha #5), `groupBy([#event_simpleName, ContextBaseFileName])` doesn't error — it returns one identity-less mega-row per event type and looks like a fleet-scale finding. Attribute by joining `ContextProcessId` → `ProcessRollup2.TargetProcessId` on the same `aid` (favorites #13). Sensor process ids are per-`aid` unique, so `(aid, pid)` is a safe key.
23. **Extension-based file hunts inherit other software's naming.** `.cap` is overwhelmingly **not** a packet capture: it's UEFI/BIOS firmware capsules (Dell R740 `payload\R740-*.cap`, ASUS `PRIME-*.CAP`, Lenovo `IMAGEM56.cap`), AMD display-driver files (`atiumd6a.cap`, riding along in `$WINDOWS.~BT\NewOS\` on every OS upgrade), and AV pattern files. Likewise `.etl` matches **Windows Error Reporting** temp files fleet-wide (`\ProgramData\Microsoft\Windows\WER\Temp\WER.*.tmp.etl`) — enough volume to blow a 1,000-row cap by itself and push your canary off the bottom of the sort. **Enumerate what an extension actually matches in your fleet before building a rule on it** (HUNT-16 Q10→Q11).


---

## 8. Scaling the Team: Lifecycle, Tooling, and Operating Model

### Query Development Lifecycle

| Phase | Actions | Exit criteria |
|---|---|---|
| **1. Requirements mapping** | Define the tradecraft, identify log sources, map to MITRE ATT&CK | Documented detection-engineering request |
| **2. Draft / translate** | Charlotte AI for new queries; Query Translation Agent for legacy SPL | Syntactically complete FQL/CQL draft |
| **3. Offline syntax review** | FQL properties lowercase + single-quoted strings; CQL comparisons wrapped where needed; correct language for the target | Compliant draft ready for sandbox |
| **4. Performance / ingest-lag check** | Measure ingestion latency and execution cost (see lag snippet below) | Acceptable execution metrics |
| **5. Sandbox testing** | Run via console or `falconpy` / automation against known data | Clean run, no timeouts or compile errors |
| **6. Production release** | Promote to dashboard, scheduled report, or correlation rule | Active rule / dashboard / report |

Ingest-lag baseline snippet (Phase 4):

```cql
| select([#repo, #Vendor, #type, @timestamp, @ingesttimestamp])
| ingest_lag_in_mins := ((@ingesttimestamp - @timestamp) / 1000) / 60
| sort(ingest_lag_in_mins, limit=20000)
```

### Acceleration tooling

- **Query Translation Agent (QTA):** auto-converts legacy SIEM queries (e.g., Splunk SPL) to optimized CQL, preserving logic and cutting migration time. Treat output as a *draft* to validate.
- **Charlotte AI / Promptbooks:** generate CQL from natural-language threat-hunt descriptions; save proven prompts as Promptbooks to standardize across the SOC. **Control: Charlotte may draft; humans must validate field names, parser quality, filters, and thresholds before promotion.**

### Lightweight operating model

Run a small "query factory": one owner for parsers/normalization, one for query authoring, one reviewer for logic/performance, one approver before anything becomes a production rule. Use saved searches as reusable building blocks, grant asset permissions intentionally, and embed validated searches into dashboards/workflows/rules instead of cloning logic.

**Per-unfinished-query worksheet:** business question · repository/source · parser/connector · representative raw event · normalized fields · time window · expected output type · aggregation/threshold · false-positive exclusions · final home (saved search / dashboard / rule / workflow).

---

## 9. Rubric: Building Powerful Queries Quickly and Accurately

Use this two-part rubric on every query before it leaves a developer's hands. Part A is a **fast build sequence** (do these in order). Part B is a **scored quality check** (target ≥ 16/20; never ship below 12, and never ship with any zero in a *Correctness* row).

### Part A — The 7-step fast build sequence

1. **State the question in one line.** "Prove or disprove: ____." If you can't, you're not ready to query.
2. **Pick the language.** SIEM search → CQL. API/automation → FQL. (Wrong choice = guaranteed rework.)
3. **Anchor the scope.** CQL: lead with time range + `#repo`/`#type` tags. FQL: pick the endpoint and confirm the field is filterable there.
4. **Add the single most selective filter** and run it. Confirm rows look right *before* adding anything else.
5. **Layer remaining filters, then project** (`select`/`table`) so output is human-readable. Extract/regex only if the field isn't already parsed/normalized.
6. **Aggregate last** (`groupBy`, `count`, `timeChart`, `stats`) on the reduced set. Watch grouping-key cardinality.
7. **Test edges**: zero-result case, false positives, and one known-true case. Then comment, name, and save.

### Part B — Scored quality rubric (0–2 each, 20 max)

| # | Dimension | 0 — Reject | 1 — Needs work | 2 — Ship-ready |
|---|---|---|---|---|
| 1 | **Right language** *(Correctness)* | Mixes FQL/CQL syntax | Correct language, minor stray syntax | Correct language throughout |
| 2 | **Clear intent** | No stated purpose | Vague purpose | One-line use case + ATT&CK mapping in a comment |
| 3 | **Scope anchored** *(Correctness)* | No time/tag/endpoint scope | Partial scope | Time + tags (CQL) or validated endpoint+field (FQL) up front |
| 4 | **Filter-early ordering** | Aggregates/regex before filtering | Some late filtering | Cheapest, most selective filters first; format/aggregate last |
| 5 | **Field accuracy** *(Correctness)* | Guessed/raw vendor fields | Mostly correct fields | Normalized (CPS/alias) fields, verified against sample events |
| 6 | **Data typing & quoting** *(Correctness)* | Wrong types/missing quotes | Minor formatting slips | Strings/dates quoted, booleans/ints bare, regex tested |
| 7 | **Precedence & logic** | Ambiguous AND/OR | Works but relies on implicit precedence | Explicit parentheses; CQL `OR`-binding handled |
| 8 | **Performance** | Full scans / high-cardinality blowups | Acceptable but heavy | Tag-scoped, bounded grouping, no needless global regex |
| 9 | **Output usefulness** | Raw dump | Readable but noisy | Projected columns / chart that answers the question directly |
| 10 | **Validated & maintainable** | Untested | Tested happy path only | Edge + false-positive tested, commented, named, saved for reuse |

**Scoring guide:** 18–20 promote to production · 14–17 minor fixes · 12–13 rework · <12 or any *Correctness* zero (#1, 3, 5, 6) → do not ship.

### Pocket checklist (tape to the monitor)

- [ ] One-line question written
- [ ] CQL (search) vs FQL (API) chosen correctly
- [ ] Time + tags / validated endpoint first
- [ ] Most selective filter added and verified
- [ ] Normalized fields, correct quoting/types
- [ ] Parentheses around all AND/OR logic
- [ ] Aggregation on a reduced set, sane grouping keys
- [ ] Output projects only what answers the question
- [ ] Edge + false-positive cases tested
- [ ] Commented, named, saved

---

## 10. Team Query Standard — Canonical Forms & Template

*Derived from a sweep of all 213 authored query files across the hunt corpus (2026-07). Where several authors wrote the same intent different ways, this section picks **one** canonical form — chosen to be both the most common and the least bug-prone — so the primitives stay copy-paste-compatible across people. Pairs with the §9 rubric (the quality gate) and the block catalog in `crowdstrike-query-primitives.md` (the parts).*

The sweep found the primitives are already *semantically* consistent — nobody is doing the wrong thing — but six surface forms diverged between authors. Two of them are latent false-zero bugs, not cosmetics. The rules below resolve each.

### 10.1 The eight canonical rules

1. **Always lead with `#repo`.** `#repo=base_sensor` / `#repo=detections` / `#repo=okta` as the first non-comment statement. A missing repo tag forces a full scan (pitfall #3). *(19/213 files omitted it — 14 of them one author's hunt.)*
2. **Platform: `event_platform=/^Win/i`.** The regex — or `in(field=event_platform, values=["Win","Windows"])` — covers the `Win`/`Windows` dual label (§5, Discovery 1). **Never bare `event_platform="Win"` / `=Win`**: it silently drops every `Windows`-tagged event — a false zero, not an error. *(34 files used the bare/quoted-exact form.)*
3. **`event_simpleName`: tagged, unquoted.** `#event_simpleName=ProcessRollup2`; for sets, `in(field=#event_simpleName, values=[…])`. Always the leading `#` (pitfall #13); never quote the field name; always `field=` inside `in()`. *(Five quoting variants were in use; the `#` itself is effectively settled — only 1 bare reference.)*
4. **Host scope by `aid`.** `| aid="<AID>"` (one host) or `| in(field=aid, values=[…])` (a set). Use `| ComputerName=/^<HOST>$/i` **only** when the aid is unknown, and carry `aid` into output to re-pin. **Never `ComputerName="literal"`** — names get reused/renamed. `aid=?param` is for saved dashboard widgets only.
5. **Every `groupBy` carries an explicit `limit`.** `limit=20000` by default (truncation-safe, pitfall #14); `limit=max` only for read-every-distinct-value passes. Never a bare `groupBy`.
6. **Time: sort numeric, humanize last, UTC by default.** `formatTime(...)` as the final statements, applied to the raw epoch *after* sorting (pitfall #18). Use `timezone="UTC"` in every saved / shared / dashboard / correlation query so cross-author results line up; `"America/Detroit"` is a local-IR-readout toggle, flagged in a comment — not baked into shared content. *(House default; the corpus is a near-even UTC/Detroit split today.)*
7. **One-line intent header, mandatory.** `// Use case: prove or disprove ____` (+ ATT&CK id where relevant). Comments elsewhere say *why*, not *what*. *(Only 3/213 carried the structured intent line.)*
8. **`case{}` hygiene.** Every branch ends `;`, assigns with `:=`, wraps comparisons in `test()`, ends with a `*` default (pitfall #4).

> **Not divergences — leave alone.** `sort(order=asc)` vs `desc` is the deliberate hunting inversion (asc floats needles; desc shows the baseline). `limit=max` vs `limit=20000` is intentional (max = read-everything). Both are semantic choices, not style drift — don't "standardize" them away.

### 10.2 The skeleton (paste-and-fill)

```cql
// HUNT-nn Query-nn: ____ (use this only if it is query for a hunt)
// Use case: prove or disprove ____   (+ ATT&CK id if relevant)
#repo=base_sensor event_platform=/^Win/i          // 1. repo + platform, dual-label-safe
| (#event_simpleName=ProcessRollup2 OR #event_simpleName=SyntheticProcessRollup2 OR #event_simpleName=ProcessBlocked)
| aid="<AID>"                                      // 2. scope (aid > ComputerName); drop for fleet-wide
| FileName=/^<name>\.exe$/i                        // 3. most-selective subject filter, verified first
| CommandLine!=/<known-good>/i                     // 4. exclusions AFTER any always-keep classifier
| case { <cond> | flag := "<label>" ; * | flag := "review" }   // 5. classify (test() around comparisons)
| groupBy([<entity>], function=[
      count(as=<n>),
      count(aid, distinct=true, as=hosts),         // count aid, never ComputerName
      collect([<context>], limit=10),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)                                 // 6. explicit limit, always
| sort(<metric>, order=asc, limit=1000)            // asc = hunt (needle-first); desc = baseline
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")  // 7. humanize last
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
```

### 10.3 Conformance checklist (tape to the monitor)

- [ ] Optional one-line `// HUNT-nn Query-nn:` intent at the top (if it is query for a hunt)
- [ ] One-line `// Use case:` intent at the top
- [ ] Leads with `#repo`; platform is `/^Win/i` or `in()` (never bare `="Win"`)
- [ ] `#event_simpleName`, tagged and unquoted; `field=` inside every `in()`
- [ ] Scoped by `aid` (or `ComputerName=/^…$/i` with `aid` carried in output) — never `ComputerName="literal"`
- [ ] Every `groupBy` has an explicit `limit`; distinct counts use `aid`
- [ ] Sort on numeric time; `formatTime` last; `timezone="UTC"` unless it's a local readout
- [ ] `case{}` branches end `;`, use `:=`, wrap comparisons in `test()`, have a `*` default
- [ ] Comments say *why*; verified against a known-true row + the zero-result case

> **Two house defaults you can flip:** the **UTC** time default (rule 6) and the `/^Win/i` **platform form** (rule 2) are the two places the corpus didn't decide for itself — both are correct. Change them team-wide here if the house preference differs; the rest of the standard is unaffected.

---

## Appendix: Fact-Check & Sourcing Notes

This playbook merges three source briefs. Key verifications performed against CrowdStrike/LogScale documentation and community sources:

- **FQL syntax** (`property:operator value`, single-quoted strings/dates, lowercase properties, `+`/`,`/`()`, `~` text match, `[ ]` exact match, 20-property cap, both stemmed and wildcard-hint forms): **confirmed.**
- **CQL `OR` binds more tightly than `AND`**: **confirmed** — genuinely documented and counterintuitive; parentheses strongly recommended.
- **CQL case statements** (semicolon-terminated clauses, `:=` assignment, default `*` branch, `test()` for comparison expressions): **confirmed.** Note: simple field filters do not require `test()`; reserve it for arithmetic/comparison expressions.
- **Index-free architecture / tag-first performance**: **confirmed.**
- **CCSE (exam CCSE-204), CFCP, CrowdStrike University tracks, Query Translation Agent (SPL→CQL), Charlotte AI AgentWorks, CPS / field aliasing**: **confirmed** as real offerings.
- **Correction applied:** one source treated *all* queries (including SIEM log search) as "FQL." That is inaccurate — SIEM search is CQL. This playbook applies the correct FQL/CQL separation throughout.
- **Field-name and coded-value notes are tenant-derived, not universal.** The tagged-field behavior (`#event_simpleName`), the `FirewallChangeOption` schema, and the `FirewallProfile` 1/2/3 enum in Use Case 11 and Pitfalls 13–16 were observed in a specific tenant and confirmed empirically (e.g., the profile enum was disambiguated by the presence of `3` and absence of `4`). Re-verify against your own tenant before operationalizing.

*Always validate field names and filterable properties in your own tenant before operationalizing, as available fields vary by endpoint, repository, parser, and platform version.*
