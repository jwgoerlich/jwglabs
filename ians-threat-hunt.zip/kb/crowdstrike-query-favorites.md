# CQL Hunt Favorites — Ready-to-Run Queries

*The greatest-hits we reach for over and over. Copy, fill the `<placeholders>`, run. Built from the working queries in `hunt/` and the blocks in `crowdstrike-query-primitives.md`.*

### How to use
- **Fill the `<placeholders>`:** `<AID>` = stable 32-hex sensor id (preferred host key — `ComputerName` gets reused/renamed); `<username>` = person, no domain; `<binary>` / `<parent>` = a process basename like `mshta`.
- **Set the time window in the console picker** — it is *not* encoded in CQL. Default to 30d for hunts, 12mo for an incident scope.
- **Timezone:** every query humanizes time as `timezone="UTC"`. Swap both lines to `"America/Detroit"` for local Eastern.
- **`aid` vs `ComputerName`:** swap `| aid="<AID>"` for `| ComputerName=/^<HOST>$/i` if you only have the name (carry `aid` in output to re-pin if more than one shows up).
- **LogonType legend:** `2`=interactive · `3`=network · `5`=service · `7`=unlock · `9`=new-creds(runas) · `10`=RDP · `11`=cached. "Hands on the box / RDP" = 2, 7, 10, 11.

---

## Host & identity scoping

### 0. Find the AID for a computer name.

#event_simpleName=* ComputerName="NAMEHERE"
| table([ComputerName, aid, AgentVersion, aip, LastSeen])
| groupBy([ComputerName, aid])


### 1. Everyone who has logged into this computer (first/last seen)
Blast radius — every person with a session on the host (password-reset / token-revoke list).
```cql
#repo=base_sensor event_platform=/^Win/i
| in(field=#event_simpleName, values=["UserLogon"])
| aid="<AID>"
// keep people: drop machine ($) and Windows pseudo-accounts (comment out to include service/machine logons)
| UserName!=/\$$/
| UserName!=/^(SYSTEM|LOCAL SERVICE|NETWORK SERVICE|DWM-\d+|UMFD-\d+|ANONYMOUS LOGON)$/i
| groupBy([UserName], function=[
      count(as=logons),
      count(LogonType, distinct=true, as=distinct_logon_types),
      collect([LogonType], limit=20),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)
| sort(last_seen, order=desc, limit=1000)
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
```
*Read:* prioritize accounts whose `last_seen` is on/after the incident — they held a session while it mattered. RDP (LogonType 10) widens the radius.

### 2. Every computer someone has logged into (first/last seen)
Follow the person across machines — find their current box, spot roaming.
```cql
#repo=base_sensor event_platform=/^Win/i
| in(field=#event_simpleName, values=["UserLogon"])
| UserName=/^<username>$/i
| groupBy([ComputerName, aid], function=[
      count(as=logons),
      count(LogonType, distinct=true, as=distinct_logon_types),
      collect([LogonType], limit=20),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)
| sort(last_seen, order=desc, limit=1000)
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
```
*Read:* the row with the most-recent `last_seen` is their active machine. Many interactive (2/7) logons = primary workstation.

### 3. Every block on this computer
Sensor prevention blocks — what Falcon actually stopped here.
```cql
#repo=base_sensor event_platform=/^Win/i
| #event_simpleName=ProcessBlocked
| aid="<AID>"
| groupBy([ParentBaseFileName, FileName, CommandLine], function=[
      count(as=blocks),
      collect([UserName], limit=10),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)
| sort(last_seen, order=desc, limit=1000)
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
```
> **"No blocks" ≠ "no attack"** (lessons-learned #9). A blocked-empty result tells you nothing — a ClickFix that *ran* never appears here. Always pair with #5 (detections) and #8 (suspicious-cmd sweep).

---

## Suggested favorites — things we do over and over

### 4. Is this host still reporting? (liveness across ALL telemetry)
The containment / "went quiet" check — measured, not inferred.
```cql
#repo=base_sensor aid="<AID>"
| groupBy(aid, function=[
      count(as=events),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
// SEE WHEN it dropped / whether it resumed (reimage vs gap):  | timeChart(span=1d, function=count(as=events))
```
*Read:* `last_seen` flat after the incident = isolated/reimaged (exposure = hours). `last_seen` ~ today = **still live** → containment is wrong, escalate.

### 5. Every Falcon detection/alert on this computer (authoritative stream)
The `detections` repo is what actually surfaces detected-but-not-prevented activity.
```cql
#repo=detections
| aid="<AID>"
| groupBy([SeverityName, Tactic, Technique, Objective, DetectName], function=[
      count(as=detections),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)
| sort(last_seen, order=desc, limit=1000)
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
```
> In `detections`, `SeverityName/Tactic/Technique/Objective` populate; `ComputerName/UserName/DetectName` may be **empty** (host keyed by `aid`). For full chronological detail + to discover the real field names, use a wide-net table:
> ```cql
> #repo=detections | aid="<AID>"
> | sort(@timestamp, order=asc, limit=20000)
> | table([@timestamp, SeverityName, Tactic, Technique, Objective, DetectName, DetectDescription,
>          PatternId, Status, aid, ComputerName, Hostname, device.hostname, UserName, LocalIP], limit=20000)
> ```
> **0 rows?** Confirm `aid` is the host key in this repo (drop the filter, wide-net `table()`, verify the id appears) before clearing — false-zero guard.

### 6. What did this process spawn? (children / payload handoff)
The lineage move — payloads hide in the child, not the parent's own command line.
```cql
#repo=base_sensor
| in(field=event_platform, values=["Win","Windows"])
| (#event_simpleName=ProcessRollup2 OR #event_simpleName=SyntheticProcessRollup2 OR #event_simpleName=ProcessBlocked)
| ParentBaseFileName=/^<parent>\.exe$/i
| groupBy([FileName, CommandLine], function=[
      count(as=executions),
      count(aid, distinct=true, as=hosts),
      collect([ComputerName, UserName], limit=10),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)
| sort(hosts, order=asc, limit=1000)
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
```
*Read:* sorted rare-first — the odd child (a shell, script host, encoded PS) on 1–2 hosts is the lead. Common parents to pivot on: `mshta`, `winrshost`, `updater`, `WmiPrvSE`, `explorer`.

### 7. How many hosts run this binary? (prevalence = sanctioned vs anomaly)
Run before judging any binary: many hosts = deployed/likely benign; few = verify.
```cql
#repo=base_sensor event_platform=/^Win/i
| (#event_simpleName=ProcessRollup2 OR #event_simpleName=SyntheticProcessRollup2)
| FileName=/^<binary>\.exe$/i
| groupBy([FileName, ImageFileName], function=[
      count(as=executions),
      count(aid, distinct=true, as=hosts),
      collect([ComputerName, UserName], limit=5),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)
| sort(hosts, order=asc, limit=2000)
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
// Single-number headline:  …| groupBy(aid, function=count(), limit=20000) | count(as=distinct_hosts)
```
*Read:* low host count is a flag to **verify**, not a verdict — check `ImageFileName` path + signature (legit tools live under Program Files/vendor dirs; `\Temp\ \AppData\ \ProgramData\<random>` = masquerade).

### 8. Suspicious cmd.exe on this computer (known-good-minus sweep)
The behavior sweep that catches ClickFix — every cmd.exe on the host minus the four benign shapes, with a ran-vs-blocked verdict.
```cql
#repo=base_sensor
| in(field=event_platform, values=["Win","Windows"])
| (#event_simpleName=ProcessRollup2 OR #event_simpleName=SyntheticProcessRollup2 OR #event_simpleName=ProcessBlocked)
| aid="<AID>"
| FileName=/^cmd\.exe$/i
// drop the four benign known-good shapes (everything else = review)
| CommandLine!=/^"*\S*cmd\.exe"*\s+(\/\S+\s+)*"*([a-zA-Z]:\\|\\\\)/i
| CommandLine!=/^"*\S*cmd\.exe"*\s+(\/\S+\s+)*(del|rmdir|rd|pushd)\b/i
| CommandLine!=/^"*\S*cmd\.exe"*\s*$/i
| CommandLine!=/^("*\S*cmd\.exe"*\s+)?\/k\s+echo\s+\{[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\}\s*$/i
| case { #event_simpleName="ProcessBlocked" | _blocked := 1 ; * | _blocked := 0 }
| groupBy(CommandLine, function=[
      count(as=executions),
      sum(_blocked, as=blocked_hits),
      collect([ParentBaseFileName, UserName, aid], limit=10),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)
| case {
    test(blocked_hits==executions) | sensor_status := "BLOCKED (all)" ;
    test(blocked_hits>0)           | sensor_status := "BLOCKED (some ran)" ;
    *                              | sensor_status := "RAN (not blocked)"
  }
| sort(last_seen, order=desc, limit=1000)
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
```
*Read:* `sensor_status = RAN` is top priority (it executed). Strip `^` carets to de-obfuscate. Drop `| aid="<AID>"` to run fleet-wide; swap it for `| UserName=/^<username>$/i` to follow the person.

### 9. Read every distinct command line for a binary (fleet-wide)
When volume is small enough to classify by eye — no pattern pre-filter, so nothing hides.
```cql
#repo=base_sensor
| (#event_simpleName=ProcessRollup2 OR #event_simpleName=SyntheticProcessRollup2)
| in(field=event_platform, values=["Win","Windows"])
| ImageFileName=/\\<binary>\.exe$/i
| groupBy([CommandLine], function=[
      count(as=executions),
      count(aid, distinct=true, as=hosts),
      collect([ComputerName, UserName, ParentBaseFileName], limit=20),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)
| sort(executions, order=desc, limit=1000)
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
```

### 10. What did this host (or process) connect to? (network egress)
Confirm a destination on the wire — independent of any attacker-controllable command line.
```cql
#repo=base_sensor
| in(field="#event_simpleName", values=["NetworkConnectIP4","NetworkConnectIP6"])
| event_platform=/^Win/i
| aid="<AID>"
// optional — scope to one tool's connections:  | ContextBaseFileName=/<binary>/i
| groupBy([ContextBaseFileName, RemoteAddressIP4, RemotePort], function=[
      count(as=conns),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)
| sort(conns, order=desc, limit=2000)
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
```
*Read:* enrich unfamiliar `RemoteAddressIP4` — check `network-knowledge.md` first, then `https://bgp.he.net/ip/<ip>` for AS/owner/PTR. DNS view companion: swap the event set to `["DnsRequest","SuspiciousDnsRequest"]` and group by `DomainName`.

---

### 11. Host suspicion sweep (every detect-flavored sensor event on this computer)
The fast "does this host have hidden trouble?" pass — enumerates all detect/suspicious-family telemetry the sensor emitted for one aid. Pairs with #5: that reads the authoritative `detections` stream; this reads the sensor-side raw signal that never became a detection.
```cql
#repo=base_sensor aid="<AID>"
| (#event_simpleName=*DetectInfo* OR #event_simpleName=Suspicious*
   OR #event_simpleName=*Inject* OR #event_simpleName=CustomIOA*
   OR #event_simpleName=ProcessBlocked* OR #event_simpleName=Ransomware*
   OR #event_simpleName=*HandleFromUnsignedModule OR #event_simpleName=SAMHashDump*
   OR #event_simpleName=TokenImpersonated OR #event_simpleName=SensitiveWmiQuery
   OR #event_simpleName=ReflectiveDotnetModuleLoad
   OR #event_simpleName=AssociateIndicator OR #event_simpleName=DetectionExcluded)
| groupBy([#event_simpleName, FileName, ContextBaseFileName], function=[
      count(as=hits),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)
| sort(hits, order=desc, limit=1000)
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
```
*Read:* **raw telemetry ≠ detections — do not escalate from names alone.** Apply the baseline lenses in order (lessons-learned §4, HUNT-15): time-shape first (flat full-window span = installed software humming; incidents cluster around a moment), identity second (which binary emits it), fleet comparison only if doubt remains. Scary names (`SAMHashDumpFromUnsignedModule`, `InjectedThread`, `RansomwareOpenFile`) routinely resolve to VPN/posture agents, DLP, and Office autosave.

> **Caveats:** (1) Identity fields vary by family — `FileName`/`ContextBaseFileName` are empty on injection events; resolve identity with a family-specific pivot before attributing. (2) When investigating a known detection, that detection is your **canary** — it must appear in the output, else the sweep is a false zero. (3) The event-name list is a tenant snapshot (Win families, 2026-07, from `event_simplenames_win.csv`) — sensor updates add/rename families, so re-derive when in doubt; a Lin host needs Linux-native families instead.

---

### 12. Who had this IP address? (IP → host, point in time)
Bind a source IP from logon or network telemetry to the sensor that held it — closes "who really made that connection." Set the picker to bracket the moment (± a day; tighter under DHCP churn).
```cql
#repo=base_sensor
| in(field=#event_simpleName, values=["LocalIpAddressIP4"])
| LocalAddressIP4="<IP>"
| groupBy([aid, ComputerName], function=[
      count(as=sightings),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)
| sort(last_seen, order=desc, limit=1000)
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
```
*Read:* one host in a tight window = your answer (carry the `aid` for pinning). Multiple hosts = DHCP reuse / VPN pool — narrow the picker around the moment. **0 rows ≠ nobody:** it means no *sensor* held that IP (VPN concentrator, thin client, printer, unmanaged box) — false-zero guard before concluding. Feeds from: `RemoteAddressIP4` on `UserLogon` rows (following up #1/#2) or network telemetry (#10).

---

### 13. Name the process behind an event that only carries a PID (the join)
Several event families identify their actor **only** by `ContextProcessId` — no `FileName`, no `UserName` (confirmed: `PromiscuousBindIP4`, `RawBindIP4`; also `*FileWritten`). Join back to process telemetry to get a name. Sensor process ids are **per-`aid` unique**, so `(aid, pid)` is a safe key — no OS-PID-reuse trap.
```cql
#repo=base_sensor event_platform=/^Win/i
| (#event_simpleName=ProcessRollup2 OR #event_simpleName=SyntheticProcessRollup2)
| ComputerName=/^(<HOST1>|<HOST2>)$/i                 // scope the PRIMARY: never join against the raw firehose
| join(query={
      #repo=base_sensor event_platform=/^Win/i
      | in(field=#event_simpleName, values=["<EVENT_WITH_ONLY_A_PID>"])
      | ComputerName=/^(<HOST1>|<HOST2>)$/i           // same scope on the subquery
      | groupBy([aid, ContextProcessId], function=[count(as=hits)], limit=20000)
    },
    field=[aid, TargetProcessId], key=[aid, ContextProcessId],
    include=[hits], mode=inner)
| groupBy([ComputerName, FileName, ImageFileName, UserName, TargetProcessId], function=[
      max(hits, as=hits),                              // max() collapses the PR2/Synthetic duplicate
      min(@timestamp, as=proc_start)
   ], limit=20000)
| sort(hits, order=desc, limit=1000)
| formatTime("%Y-%m-%d %H:%M:%S", field=proc_start, as=proc_start, timezone="UTC")
```
*Read:* **invert the join** — the tiny aggregated PID set is the *subquery*; the process stream is the primary it filters. Joining the other way pushes millions of rows through the subquery caps. **Set the picker LONG (1y):** a long-lived agent's process-start can be months older than the event you're attributing, and an inner join silently drops any actor whose start you can't see. If a target host returns nothing, that's a coverage hole to resolve — not a clean negative. (HUNT-16 q04.)

### 14. Unattended use of a dual-use tool (the "who launched it" discriminator)
For any tool that is benign in a human's hands and hostile in a script's — capture tools, archivers, `curl`, RMM, `psexec` — the **parent process is the finding**. Run it in two tiers; the tiers have very different precision.

**Tier 1 — scheduler/service parent = ALERT.** Measured over 1y fleet-wide: **exactly 1 hit, 0 false positives** (HUNT-16's `C:\drop.pcap` job).
```cql
#repo=base_sensor event_platform=/^Win/i
| (#event_simpleName=ProcessRollup2 OR #event_simpleName=SyntheticProcessRollup2 OR #event_simpleName=ProcessBlocked)
| FileName=/^(dumpcap|tshark|windump|rawcap|pktmon)\.exe$/i          // <- swap in your dual-use tool set
| ParentBaseFileName=/^(svchost|taskeng|taskhostw|services)\.exe$/i  // scheduler/service ONLY
| groupBy([ComputerName, aid, UserName, FileName, ParentBaseFileName], function=[
      count(as=executions),
      collect([CommandLine], limit=5),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)
| sort(last_seen, order=desc, limit=1000)
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
```
**Tier 2 — shell parent = HUNT, don't alert.** Swap the parent set for `/^(cmd|powershell|wscript|cscript)\.exe$/i`. A shell parent is genuinely ambiguous: a human typing in a console looks identical to a script. Over 1y this returned 2 benign rows (offline `-r` analysis, and a VoIP tech running live `tshark` from `cmd`).

*Read:* `svchost`/`taskeng`/`taskhostw` parent = **scheduled task** → check for a `ScheduledTaskRegistered` event; **if none exists in the window, the task predates retention and telemetry cannot name its creator** (say so plainly; hand attribution to asset/change records). A human at a keyboard shows `explorer.exe` or the tool's own GUI as parent — that's the benign population you're *not* looking for.

> **Trap (cost us a wrong precision claim):** `CommandLine!=/\s-r[\s"]/i` looks like it excludes offline analysis, but **the exclusion is per command line while the finding is per row** — a `groupBy` row whose `collect()` holds five command lines, only one of which has `-r`, survives the filter intact. Don't quote a rule's precision from row counts until you've read the *individual command lines* in the surviving rows. (HUNT-16, caught in adversarial review.)
>
> **Do NOT hunt packet capture with `PromiscuousBindIP4`.** npcap captures at the NDIS layer and never emits it; pcap writes never emit `*FileWritten` either. Process execution is the only signal that works in this tenant (lessons-learned #17/#18).

### 15. When did this host last reboot? (boot time + uptime)
Boot time and uptime per Windows host, from the sensor's own boot marker (`AgentOnline.BaseTime`). Two jobs, two filters (both inline below): **investigation** — pull the reboot picture for one computer; **patch hygiene** — sweep the fleet for anything not rebooted (= not patched) in 30+ days.
```cql
// Use case: when did each Windows host last boot, and how long ago?
// Source: AgentOnline = sensor coming online; BaseTime = boot marker in sensor-native units.
#repo=base_sensor event_platform=/^Win/i
| #event_simpleName=AgentOnline
// INVESTIGATION — scope to one computer:   | aid="<AID>"   or   | ComputerName=/^<HOST>$/i
| groupBy([aid], function=[
      count(as=sensor_onlines),               // times the sensor came online in-window (1 = stable; many = cycling)
      selectLast([ComputerName, BaseTime])    // latest hostname + latest boot marker per aid
   ], limit=20000)
// BaseTime → Unix ms: ×1024/1000 = seconds since 2001-01-01; +978307200 rebases to 1970; ×1000 = ms
| last_reboot := ((BaseTime * 1024 / 1000) + 978307200) * 1000
| round(last_reboot)
| reboot_ago := now() - last_reboot
// PATCH HYGIENE — keep only hosts NOT rebooted in the last 30 days (tune threshold; see picker caveat):
//   | test(reboot_ago > 2592000000)          // 30d = 30*24*3600*1000 ms
| sort(last_reboot, order=asc, limit=20000)   // stalest boots first; flip to desc for most-recent reboots
| formatDuration(field=reboot_ago, precision=2)
| formatTime("%Y-%m-%d %H:%M:%S", field=last_reboot, as=last_reboot, timezone="UTC")
```
*Read:* investigation mode — `last_reboot`/`reboot_ago` say when the box last bounced; pair with #4 (liveness) to tell *rebooted* from *went dark*, and note `sensor_onlines` ≫ reboots = the sensor cycling without boots. Patch mode — survivors of the 30-day filter are the "no patch-cycle reboot" review list; grouped by `aid` with the name via `selectLast`, so a renamed host stays one row under its current name.

> **Picker false-zero:** a host appears only if it emitted `AgentOnline` *inside the window* — an absent host is not "recently rebooted," its last sensor-online just predates the picker (or the sensor is gapped). Run the fleet sweep at 90d–1y so the long-uptime hosts — the very targets — can't fall out. And the ×1024 `BaseTime` conversion is Windows-specific community math: spot-check one known host against `systeminfo` "System Boot Time" before trusting it fleet-wide (raw `BaseTime` rides along in the output so any row can be re-checked). Don't reuse the formula on Mac/Lin.


### 16. What links did users open from Outlook? (unwrap SafeLinks/Avanan → real destination)
For a given computer — what a user actually clicked through to from an Outlook email — or, fleet-wide, as a phishing threat-hunt generator. Reconstructs the true destination host from the browser command line, unwrapping the email-security rewriters (Microsoft SafeLinks, Avanan/Check Point) that otherwise leave you staring at `url.avanan.click`.
```cql
// Use case: which hosts did users actually browse to from Outlook links?
#repo=base_sensor
| in(field=event_platform, values=["Win","Windows"])
| #event_simpleName=ProcessRollup2
| aid="<AID>"                                  // one computer (INVESTIGATION); ComputerName form: | ComputerName=/^<HOST>$/i
                                               // DROP this line = fleet-wide (THREAT HUNT);  ?aid = dashboard-widget input
| ParentBaseFileName=/^outlook\.exe$/i         // links opened from the Outlook desktop client
| FileName=/^(msedge|chrome|firefox|iexplore)\.exe$/i   // msedge is the Windows default — omitting it hides most clicks
| ChildFileName := FileName                    // remember which browser…
| FileName := ParentBaseFileName               // …then relabel so the row reads outlook -> browser
// 1. outer host — every URL-bearing launch gets a value
| regex("(?i)https?:/+(?<DNSHost>[A-Za-z0-9.-]+)", field=CommandLine, strict=false)
// 2. SafeLinks rewrap → its url= target (which may itself be Avanan; stage 3 handles that)
| regex("(?i)safelinks\\.protection\\.outlook\\.com/.*?url=https?%3a%2f%2f(?<DNSHost>[A-Za-z0-9.-]+)", field=CommandLine, strict=false)
// 3. Avanan rewrap → the true inner host. LAST so it overrides any outer wrapper.
//    tolerates /v2/ and /v2/r01/, 2+ underscores, %-encoded slashes, scheme-less inner URLs
| regex("(?i)avanan\\.click(?:/|%2f)\\S*?_{2,}(?:https?(?::|%3a)(?:/|%2f)+)?(?<DNSHost>[A-Za-z0-9.-]+)", field=CommandLine, strict=false)
| default(field=DNSHost, value="(invalid url in CommandLine)")   // label launches with no URL (session restore, taskbar)
| groupBy([aid, ComputerName, FileName, ChildFileName, DNSHost, CommandLine], function=[
      count(as=clicks),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=max)
| sort(clicks, order=desc, limit=20000)
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
```
*Read:* investigation mode pins one host and shows every destination that user reached from email. Threat-hunt mode drops the `aid` line, runs fleet-wide, then screens the distinct `DNSHost` column against IOC feeds + phishing heuristics (brand-lookalike, risky TLD, free-hosting, lure-shaped tenants) — that's exactly how the `usinterpol.sharepoint.com` lead surfaced. `ChildFileName` tells you which browser; add `UserName` to the groupBy to attribute per person.

> **Three false-zero traps, learned the hard way (export-02):** (1) **Include `msedge`** — Edge is the Windows default; `chrome|firefox|iexplore` alone hides most clicks. (2) **Order the unwrap outer→SafeLinks→Avanan and let Avanan win** — the wrapper is `___` (3+ underscores), shows as `/v2/` *or* `/v2/r01/`, sometimes %-encodes its slashes, sometimes has no inner scheme; a stage anchored on `/v2/r01/__https` returns the wrapper's own host (`url.avanan.click`) instead of the real one. (3) **Shorteners & trackers hide the final hop** — `bit.ly`, `lnks.gd`, `qrco.de`, `*.awstrack.me`, `*.govdelivery.com` show only the first redirect, so a bad link behind one reads benign. And the `limit=20000` cap (pitfall #14) drops rare destinations — narrow the picker (a week at a time) to see the long tail.


### 17. Where has this user logged in from? (unique Okta sign-in locations)
For a given Okta user — every distinct geographic location they **successfully** signed in from over the window. Account-takeover / impossible-travel lead: the rare, one-off location is the needle, so it's sorted to float up.
```cql
// Use case: prove or disprove — this Okta user only signed in from expected locations (impossible-travel / account-takeover lead). ATT&CK T1078.004
#repo=okta #event.outcome=success                        // repo + tagged outcome first; success = actually "logged into" (A3)
| event.action=/user\.(authentication|session\.start)/i   // Okta auth + session-start events (A3 oktaAuth primitive)
| user.name=/^<user>@oakgov\.com$/i                        // subject: one person, anchored + case-insensitive (B6 followPerson)
// location key — VERIFY these geo subfields against a raw event; an empty/absent subfield silently drops the row (pitfall #13 / gotcha #5)
| groupBy([client.geo.country_name, client.geo.region_name, client.geo.city_name], function=[
      count(as=logins),
      count(client.ip, distinct=true, as=distinct_ips),    // F2: how many source IPs per location
      collect([client.ip], limit=10),                      // F3: sample the IPs for enrichment
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)                                         // explicit limit (rule 5)
| sort(logins, order=asc, limit=1000)                      // G1: asc floats rare/one-off locations up (the hunt); flip to last_seen desc for recency
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")   // humanize last, UTC default (rule 6)
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")   //   → swap both to "America/Detroit" for a local readout
```
*Read:* sorted rare-first — a country/region/city the user hit only once, or a `distinct_ips` cluster that doesn't match their known home/office, is the lead. Drop `#event.outcome=success` (or swap to `failure`) to ask "attempted-from" instead of "logged-into." Fleet-wide variant: drop the `user.name` line and add it to the `groupBy` key to profile everyone's locations at once.

> **Verify before trusting field names.** `client.ip` is tenant-confirmed (C3), but `client.geo.country_name` / `region_name` are extrapolated from the tenant's own `client.geo.city_name` — enumerate a raw Okta event (H2 `enumField`) to confirm the exact subfield names first, or an empty geo field silently drops rows (H3 false-zero guard). `city_name` alone merges same-named cities across countries (Portland OR vs ME, London UK vs ON); the country/region keys keep them apart.
>
> **Optional egress lens (C3).** Add `| client.ip!=/^12\.43\.(10|11)\./` to strip the oakgov egress NAT (12.43.10.0/23) so the office/VPN location stops dominating the counts and the outside-the-network sign-ins stand out.


### 18. What devices/browsers has this user signed in from? (unique Okta user-agents)
For a given Okta user — every distinct device/browser (user-agent) they **successfully** signed in with over the window. New-device / account-takeover lead: a rare, one-off user-agent (often from an unfamiliar IP) is the needle, so it's sorted to float up. *Sibling of #17: same "know this user" pass, keyed on device instead of location.*
```cql
// Use case: prove or disprove — this Okta user only signs in from their known devices/browsers (new-device / account-takeover lead). ATT&CK T1078.004
#repo=okta #event.outcome=success                        // repo + tagged outcome first; success = actually "logged into" (A3)
| event.action=/user\.(authentication|session\.start)/i   // Okta auth + session-start events (A3 oktaAuth primitive)
| user.name=/^<user>@oakgov\.com$/i                        // subject: one person, anchored + case-insensitive (B6 followPerson)
// device/browser key — user_agent.original is the full UA string; VERIFY any added user_agent.* subfields per tenant (pitfall #13 / H3)
| groupBy([user_agent.os.name, user_agent.original], function=[
      count(as=logins),
      count(client.ip, distinct=true, as=distinct_ips),    // F2: how many source IPs used this device/UA
      collect([client.ip], limit=10),                      // F3: sample the IPs for enrichment
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)                                         // explicit limit (rule 5)
| sort(logins, order=asc, limit=1000)                      // G1: asc floats rare/one-off devices up (the hunt); flip to last_seen desc for recency
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")   // humanize last, UTC default (rule 6)
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")   //   → swap both to "America/Detroit" for a local readout
```
*Read:* sorted rare-first — a user-agent seen once, or one whose `distinct_ips` don't match the user's known home/office, is the lead. Drop `#event.outcome=success` (or swap to `failure`) to ask "attempted-from which device." Widget form: swap the `user.name` regex for `user.name=?username` (rule 4, dashboard input only).

> **`user_agent.original` is high-cardinality and version-churny (pitfall #6).** Every browser auto-update mints a "new" UA string, so a dozen rows can be one laptop patched over the window — fine as a rare-sign-in *hunt*, misleading as a *device count*. For a stable device tally, group on a coarser key (OS + browser family) or an Okta device-trust / device-token field if your tenant carries one — enumerate a raw event (H2 `enumField`) to confirm which device fields actually populate before trusting them (H3 false-zero guard).
>
> **Note:** `user_agent.original` already encodes the OS, so `user_agent.os.name` in the key never splits a row further — it rides along as a readable column.


### 19. Where did this file come from? (MOTW provenance: download URL, referrer, zone)
For any file that arrived on disk — was it downloaded, from where, by which browser? `MotwWritten` carries the Mark-of-the-Web the moment it's written; `ZipFileWritten`/`GenericFileWritten` bracket the write and name the writer. Provenance beats name-judging: a scary filename from a sanctioned tenant and a friendly filename from QWINS infra sort themselves out here.
```cql
// Use case: prove or disprove — <FILE> arrived from a sanctioned source (download provenance via MOTW)
#repo=base_sensor event_platform=/^Win/i
| aid="<AID>"
| in(field=#event_simpleName, values=["MotwWritten","ZipFileWritten","GenericFileWritten"])
| TargetFileName=/<FILE_PATTERN>/i          // e.g. /Case-\d+\.zip/i — a pattern, not one name: siblings corroborate
| table([@timestamp, #event_simpleName, TargetFileName,
         HostUrl, ReferrerUrl, ZoneIdentifier,
         ContextBaseFileName, ContextImageFileName, ContextProcessId], limit=20000)
| formatTime("%Y-%m-%d %H:%M:%S", field=@timestamp, as=seen, timezone="UTC")
```
*Read:* `HostUrl` is the answer (the actual download URL); `ReferrerUrl` is the page that served it; `ZoneIdentifier` 3 = Internet zone. A `MotwWritten` may emit several rows per file with the URL populated on only one — read the set, not the first row. Writer identity: `ContextBaseFileName` populates on `ZipFileWritten` (e.g. `chrome.exe`) but is often empty on `MotwWritten` — resolve via the `(aid, ContextProcessId)` join (#13) if you need it.

> **Field names verified in-tenant 2026-07-20 (HUNT-21):** `HostUrl`, `ReferrerUrl`, `ZoneIdentifier` populate on `MotwWritten`. **False-zero guards:** URL columns empty → wide-net a raw event before concluding (pitfall #13 / H2); zero rows at 30d → the file arrived by a non-MOTW path (OneDrive sync, network copy, USB) or predates the picker — widen to 1y and pivot to `FileCreateInfo`/`*FileWritten` + the PID join, don't declare "never downloaded." The shortener/tracker caveat from #16 applies to `ReferrerUrl` too.


### 20. What software is installed on this computer? (and what is the box *for*?)
The "know the host before you judge its telemetry" pass — the installed-application inventory for one `aid`, which doubles as a role read (GIS workstation vs. DBA box vs. infrastructure). Run it *before* #11 and #7: much of what looks alarming on a host is explained by what is legitimately installed on it.
```cql
// Use case: prove or disprove — the software on <HOST> matches its expected role (host baseline / role identification)
#repo=base_sensor event_platform=/^Win/i
| #event_simpleName=InstalledApplication        // the inventory family — without it, the count counts ALL telemetry, not apps
| aid="<AID>"                                   // one computer (INVESTIGATION); DROP this line for the fleet variants below
| groupBy([aid, ComputerName], function=[
      count(as=inv_events),                              // app RECORDS seen in-window (re-reports duplicate) — not a distinct count
      count(AppName, distinct=true, as=distinct_apps),   // the honest "how much software" number
      collect([AppName, AppVendor], limit=200),          // 40 truncates a real workstation — see the truncation caveat
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)
| sort(last_seen, order=desc, limit=1000)
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="UTC")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="UTC")
// ONE APP PER ROW (readable, and no collect cap at all — use when the list itself is the deliverable):
//   …| groupBy([AppName, AppVendor], function=[count(as=records), max(@timestamp, as=last_seen)], limit=max)
// FLEET PREVALENCE ("who else has this?" — the installed-software analog of #7):
//   drop the aid line | groupBy([AppName, AppVendor], function=[count(aid, distinct=true, as=hosts), collect([ComputerName], limit=20)], limit=max) | sort(hosts, order=asc, limit=2000)
```
*Read:* the app list is a **role signature** — read it as a set, not line by line. Esri/AutoCAD = engineering or GIS seat; SSMS/Oracle client = DBA or app-admin box; RMM + hypervisor tools + no Office = infrastructure, not a person's desk. Pair with #1 (who logs into it) and the hostname-convention classifier (primitives D4) for the workstation-vs-server read, and with #16 for what the human actually does on it. Then use the list as the **baseline lens for #11**: VPN/posture agents, DLP, and backup software are precisely what makes `SAMHashDump`-flavored telemetry benign — if the scary event's emitter is on this list, that's your explanation, not your finding.

> **Truncation is the trap here (F3 / pitfall #14).** This query returns *one row*, so `collect(limit=40)` isn't sampling 40 of many rows — it **is** the whole answer, silently cut. A normal workstation carries 60–150+ entries, and the tail is where the odd tool lives. Raise the limit, or use the one-app-per-row form, which has no collect cap.
>
> **Two false-zero guards.** (1) **Verify the field names.** `InstalledApplication` is confirmed in this tenant's Win event set (playbook §5), but `AppName`/`AppVendor` are **extrapolated, not tenant-verified** — enumerate a raw event (H2/H1) before trusting them, or an empty field drops silently and you get a row with a count and no apps (pitfall #13). (2) **Set the picker long — 30d minimum, 90d for a clean read.** Inventory events are periodic/on-change, not continuous; a 24h window shows what the sensor happened to report, not what is installed. An absent app is not an uninstalled app.
>
> **Installed ≠ running, and installed ≠ everything.** This is registry/MSI-visible inventory: portable EXEs in `%APPDATA%`, LOLBins, and run-from-USB tooling never appear. Prove *execution* with #7 (prevalence) or #9 (every command line). Siblings worth the same pass: `InstalledBrowserExtension` (extension governance, HUNT-14), `InstalledUpdates` + `OsVersionInfo` (patch posture, pairs with #15's reboot check).

---

*More patterns to compose your own: see `crowdstrike-query-primitives.md`. The why/how and pitfalls: `crowdstrike-query-playbook.md`.*
