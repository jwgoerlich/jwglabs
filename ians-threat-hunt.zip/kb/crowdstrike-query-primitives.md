# CQL Hunt Primitives — Reusable Building Blocks

*Distilled from every query in the `hunt/` folder (70 query files across 8 hunts: clickfix-cmd, clickfix-mshta, hunt-01 okta-spray, hunt-02 wmic, hunt-03 masquerade-parents, hunt-05/06 rmm, youngsl). Pairs with `crowdstrike-query-playbook.md` (the "how/why") and `crowdstrike-hunt-lessons-learned.md` (the environment facts).*

> **What this is.** A catalog of the small, repeating chunks our hunt queries are actually made of — the parts worth turning into saved searches, CQL functions/macros, or copy-paste snippets. Each entry is written **parameterized**: `$NAME` marks the part that changes between uses (the future "argument"). A real hunt query is mostly just these blocks stacked in pipeline order:
>
> ```
> SOURCE/scope  →  SUBJECT/target  →  EXCLUDE noise  →  CLASSIFY (case)  →  EXTRACT/enrich  →  AGGREGATE  →  SORT + humanize
>    (A)              (B)               (C)              (D)                (E)                (F)            (G)
> ```
>
> "Seen in: N" = number of the 70 query files that use the block (grep-verified), so you can prioritize which to formalize first.

---

## A. Source / scope preambles

These set repo + platform + event type. Always first (filter-early, playbook §3).

### A1 — `winProcEvents` · Windows process-execution scope — **Seen in: 44 (most common block)**
The single most repeated preamble. Scopes to Windows process telemetry, **deliberately including Synthetic + Blocked** so a prevented or rolled-up run can't produce a false zero (lessons-learned #9).
```cql
#repo=base_sensor
| in(field=event_platform, values=["Win","Windows"])
| (#event_simpleName=ProcessRollup2 OR #event_simpleName=SyntheticProcessRollup2 OR #event_simpleName=ProcessBlocked)
```
- **Params:** the event-type set. Three observed presets:
  - `["ProcessRollup2","SyntheticProcessRollup2","ProcessBlocked"]` — sweeps/hunts (catch prevented runs).
  - `["ProcessRollup2","SyntheticProcessRollup2"]` — "did it actually run?" (blocked runs intentionally excluded, e.g. clickfix-mshta Q7).
  - `["ProcessRollup2","ProcessBlocked"]` — wmic hunts.
- **Variants:** platform written two ways — `in(field=event_platform, values=["Win","Windows"])` **or** `event_platform=/^Win/i`. Both cover the `Win`/`Windows` normalization gap (playbook §5). Pick one and standardize.
- **Note:** in hunt-03, `#event_simpleName` is quoted as a tagged field at the front: `"#event_simpleName"=ProcessRollup2 event_platform="Win"`. Same idea; confirm the `#` per tenant (pitfall #13).

### A2 — `detections` · Falcon detection/alert scope — Seen in: ~7
Authoritative alert stream (not base_sensor). Host/user often live under non-obvious field names here, so pair with a wide-net `table()` (H1) or `@rawstring` (E4).
```cql
#repo=detections
| $SCOPE        // aid="..."  OR  @rawstring=/$TOOL/i  OR  Tactic!=""
```
- **Common scopes:** `aid="$AID"` (host), `@rawstring=/$TERM/i` (field-agnostic), `Technique!=""` / `Tactic!=""` (drop untagged telemetry before ranking).

### A3 — `oktaAuth` · Okta auth-outcome scope — Seen in: 7 (hunt-01)
```cql
#repo=okta #event.outcome=$OUTCOME          // success | failure
| event.action=/user\.(authentication|session\.start)/i
```
- **Note:** outcome is the **tagged, lowercase** field `#event.outcome` (lessons-learned §1). `event.action` swaps for `system.iwa_agentless.auth` (agentless IWA) etc.

### A4 — `netConn` · Network-connection scope — Seen in: 2 (hunt-06)
```cql
#repo=base_sensor
| in(field="#event_simpleName", values=["NetworkConnectIP4","NetworkConnectIP6"])
| event_platform=/^Win/i
```
- **Companion presets:** DNS → `["DnsRequest","SuspiciousDnsRequest"]`; inbound → `["NetworkReceiveAcceptIP4"]` (WinRM source on 5985/5986).

### A5 — `usbDc` · Device-control (USB/Bluetooth) scope — Seen in: 5 (hunt-02)
```cql
#repo=base_sensor event_platform=/^Win/i
| in(field=#event_simpleName, values=["DcUsbDeviceConnected","DcUsbDeviceDisconnected",
      "DcUsbDeviceProperties","DcUsbInterfaceDescriptor","DcUsbConfigurationDescriptor","DcUsbHIDDescriptor",
      "DcBluetoothDeviceConnected","DcBluetoothDeviceProperties"])
```

### A6 — `logon` · Successful-logon scope — Seen in: 4 (youngsl, hunt-02)
```cql
#repo=base_sensor event_platform=/^Win/i
| in(field=#event_simpleName, values=["UserLogon"])
```
- **Pairs with** the LogonType legend (D-note): 2=interactive, 3=network, 5=service, 7=unlock, 9=new-creds, 10=RDP, 11=cached.

---

## B. Subject & target selectors

What process / host / user the hunt is about. Anchored, case-insensitive regex throughout.

### B1 — `procIs` · Process basename match — **Seen in: 36**
```cql
| FileName=/^$NAME\.exe$/i        // e.g. /^cmd\.exe$/i , /^wmic\.exe$/i , /^acslaunch_win-64\.exe$/i
```
- `^…$` + `/i` = exact basename, case-insensitive. The workhorse selector.

### B2 — `imageIs` · Full image-path (endswith) match — Seen in: ~10
```cql
| ImageFileName=/\\$NAME\.exe$/i     // /\\mshta\.exe$/i ; or a folder tell: /\\ScreenConnect\.Client/i
```
- Use when you need the **path**, not just the basename (catches install-path-only tools; maps to Sigma `Image|endswith`). **Caveat:** if `ImageFileName` is blank in-tenant, fall back to `FileName` (basenames only) — pitfall #13.

### B3 — `parentIs` · Parent-process (lineage) selector — **Seen in: 28**
```cql
| ParentBaseFileName=/^$PARENT\.exe$/i   // explorer.exe (Run-dialog), updater.exe, WmiPrvSE.exe, winrshost.exe, mshta.exe
```
- The lineage primitive. `explorer.exe` = Run-dialog/ClickFix vector; `WmiPrvSE.exe` = remote-WMI target side; `winrshost.exe` = inbound WinRM session.

### B4 — `toolOrParent` · Tool as process **or** launcher — Seen in: 3 (hunt-02)
```cql
| (FileName=/$TOOL/i OR ParentBaseFileName=/$TOOL/i)   // qflipper, burpsuite
```

### B5 — `pinHost` · Stable host pin by `aid` — **Seen in: 12**
```cql
| aid="$AID"                                   // single host
| in(field=aid, values=["$AID1","$AID2"])      // a person's set of boxes
```
- **Why `aid` not `ComputerName`:** ComputerName can be reused/renamed over a long window; `aid` is the stable sensor id. Carry `aid` into output even when scoping by name, so you can re-pin if more than one shows up.

### B6 — `userIs` / `followPerson` · Identity selector
```cql
| UserName=/^$USER$/i      // follow the PERSON across machines (vs pinning a host)
```

---

## C. Known-good / noise exclusions

Negative filters that strip benign baseline so the residue is the lead. Always placed **after** any always-keep classifier (D3) so an exclusion can never hide real abuse.

### C1 — `dropBenignCmd` · The 4 benign cmd.exe shapes — **Seen in: 6** (clickfix-q3/4/5, youngsl-q2/9)
The most reusable exclusion *set*. Drops the high-volume benign cmd noise, leaving ClickFix-shaped commands.
```cql
| CommandLine!=/^"*\S*cmd\.exe"*\s+(\/\S+\s+)*"*([a-zA-Z]:\\|\\\\)/i      // 1. drive/UNC file runner (C:\… or \\server\…)
| CommandLine!=/^"*\S*cmd\.exe"*\s+(\/\S+\s+)*(del|rmdir|rd|pushd)\b/i    // 2. delete/dir builtins (OneDrive housekeeping)
| CommandLine!=/^"*\S*cmd\.exe"*\s*$/i                                    // 3. bare cmd (nothing executes)
| CommandLine!=/^("*\S*cmd\.exe"*\s+)?\/k\s+echo\s+\{[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\}\s*$/i  // 4. /k echo {GUID} probe
```
- **Critical detail (pitfall #17):** the `("*\S*cmd\.exe"*\s+)?` prefix is **optional** because this tenant logs some cmd lines args-only. A required prefix silently drops everything on args-only rows (999/1000 false-zero flood).

### C2 — `keepPeople` · Drop machine + pseudo accounts — Seen in: 1 (youngsl-q3), reusable everywhere
```cql
| UserName!=/\$$/                                                              // machine accounts end in $
| UserName!=/^(SYSTEM|LOCAL SERVICE|NETWORK SERVICE|DWM-\d+|UMFD-\d+|ANONYMOUS LOGON)$/i
```

### C3 — `dropEgressNat` · Exclude known egress / placeholder (Okta) — Seen in: 4 (hunt-01)
```cql
| client.ip!=/^12\.43\.(10|11)\./        // oakgov egress NAT (12.43.10.0/23)
| user.name!="system@okta.com"           // delegated-AD-agent placeholder, not a person
```
- **Why:** in a federated tenant, "many users from one IP" is a NAT gateway, not a sprayer. Excluding these makes distinct-user / distinct-IP counts honest.

### C4 — `allowlistStack` · Known-good READ suppression (wmic) — Seen in: 2 (hunt-02 q9/q11)
A stack of `CommandLine!=/…/i`, each requiring a read verb (`get`/`list`) so a suspect verb can never be suppressed. Reference list: `kb/wmic-known-good.md`.
```cql
| CommandLine!=/(?:win32_)?computer ?system.*\bget\b/i
| CommandLine!=/\b(os|qfe)\b.*\b(get|list)\b/i
| CommandLine!=/(baseboard|memorychip|diskdrive|logicaldisk|cpu|bios|csproduct).*\bget\b/i
| ...   // one line per known-good family
```
- **Lookup-driven variant:** `| !in(field=tool, values=["TeamViewer","NinjaOne RMM", …sanctioned…])` after a `match()` (E5) — suppress by enriched column instead of raw regex.

### C5 — `excludeKnownGood` · Single-line vendor-path / account exclusions — Seen in: hunt-03
```cql
| ImageFileName!=/\\$VENDOR_DIR\\/i        // \\Google\\GoogleUpdater\\ , \\Amazon\\SSM\\ …
| CommandLine!=/$KNOWN_GOOD_PATTERN/i      // GoogleUpdater.+uninstall\.cmd , Amazon.SSM.Update …
| UserName!=/^$SVC_ACCT$/                  // after lower(): servicesectigo, servicepickle …
```
- **Tip seen in q07:** use `.` instead of `\\` for path separators in exclusions to dodge backslash-escaping.

---

## D. Classifiers — `case {}` → flags & verdicts

Fold raw events into a labeled field. Each branch ends `;`, assigns with `:=`, wraps comparisons in `test()`, ends with a `*` default (pitfall #4). **Seen in: 12.**

### D1 — `flagBlocked` + `verdictRanBlocked` · Did it run or was it prevented? — Seen in: 4 (clickfix-q5, youngsl-q2/q9)
Two halves, one before the groupBy (per-event flag) and one after (row verdict from the summed counts).
```cql
| case { #event_simpleName="ProcessBlocked" | _blocked := 1 ; * | _blocked := 0 }
  ...  groupBy(..., function=[count(as=executions), sum(_blocked, as=blocked_hits), ...])  ...
| case {
    test(blocked_hits==executions) | sensor_status := "BLOCKED (all)" ;
    test(blocked_hits>0)           | sensor_status := "BLOCKED (some ran)" ;
    *                              | sensor_status := "RAN (not blocked)"
  }
```
- **Why:** "BLOCKED (some ran)" / "RAN" is the highest-priority signal — the command executed at least once. Directly answers lessons-learned #9.

### D2 — `outcomeCounters` · Fold success/failure into sums — Seen in: 2 (hunt-01 q6/q7)
```cql
| case { #event.outcome=success | s := 1 ; * | s := 0 }
| case { #event.outcome=failure | f := 1 ; * | f := 0 }
  ...  groupBy([$ENTITY], function=[ sum(f, as=failures), sum(s, as=successes) ])  ...
| failures >= $MIN_FAIL | successes >= $MIN_SUCCESS
```
- The fail-then-success / spray-landing primitive. Post-filter thresholds + ascending sort (G1) surface low-and-slow needles.

### D3 — `tagSuspectFirst` · Always-keep suspect verbs, then suppress — Seen in: 4 (hunt-02)
Tag high-risk tradecraft **before** the known-good stack (C4) so exclusions can't hide it.
```cql
| case {
    CommandLine=/(process\s+call\s+create|\/node:|shadowcopy|\/format:[\"']?(http|https|\\\\|[^ ]*\.xsl)|call\s+(terminate|delete)|__event(filter|consumer)|stdregprov\s+call\s+(set|delete)value)/i | flag := "SUSPECT" ;
    *                                                                                                                                                                                                    | flag := "review"
  }
```
- Also used to tag suspicious **children of WmiPrvSE / winrshost** (`cmd|powershell|mshta|rundll32|regsvr32|wscript|cscript|certutil…`).

### D4 — `hostClassByName` · Split workstations from servers by naming convention — Seen in: 1 (cmd/query-15, ShareFile SZC sweep), reusable
Telemetry carries no "host type" field, but the **hostname convention does**. Fold it into a class so the rows you care about float to the top.
```cql
// classify by hostname convention: NB*/WS* = user endpoints.
// everything else = server-class, the rows this hunt is about. Verify the convention holds.
| case {
    ComputerName=/^($WORKSTATION_PREFIXES)/i | host_class := "Workstation" ;
    *                                        | host_class := "Server-REVIEW"
  }
  ...  groupBy([host_class, ComputerName, ...], ...)  ...
| sort(host_class, order=desc, limit=$N)     // "Server-REVIEW" > "Workstation" alphabetically → servers first
```
- **Params:** `$WORKSTATION_PREFIXES` = `NB|WS` in this tenant (laptops/desktops). Server-class names observed: `TSNMOV*3P`, `LND*`, `OCA-*`, `CLM*`, `GIS*`, `OAKAPP*`, `MUG-WEB-*`, `*-1P/1Q/1D` (P/Q/D = prod/QA/dev suffix).
- **Why it works:** the label is the *sort key* — naming `Server-REVIEW` so it sorts above `Workstation` (desc) puts the review population on screen without a second query.
- **Use with (E-block/context):** pair with `collect([ContextBaseFileName])` — within the server rows, a **browser** process = a human on the console (workstation behavior on server hardware, e.g. terminal servers); a **service** process on a steady cadence = the server actually running the software. That pairing is what disproved an on-prem ShareFile Storage Zone Controller in query-15.
- **Caveat:** a convention, not ground truth — one renamed or non-conforming host lands in the wrong class silently. Sanity-check with `groupBy(ComputerName)` on a known set before relying on it, and prefer a real asset/host-type source if one exists in-tenant.

---

## E. Extractors & enrichers

Pull structured fields out of free text, or add context from a lookup.

### E1 — `namedCapture` · Inline named-capture regex — Seen in: hunt-01, hunt-06
```cql
| $FIELD=/$PATTERN(?<$ALIAS>$SUBPATTERN)/i
// e.g. event.reason=/result=(?<auth_result>\w+) for client=(?<target_acct>[^@]+)@/i
```

### E2 — `extractEnrich` · Non-dropping extraction (`strict=false`) — Seen in: 1 (hunt-06 q1), high-value pattern
Enrich a row when the pattern is present, **never drop** a row when it isn't. Ideal for parsing tool args (ScreenConnect relay/port/role).
```cql
| regex("[?&]h=(?<sc_relay>[^&\"'\\s]+)", field=CommandLine, strict=false)
| regex("[?&]p=(?<sc_port>[0-9]+)",       field=CommandLine, strict=false)
```
- Contrast: `strict=true` (the `match()` default) keeps only matched rows.

### E3 — `normalizeCase` · Lowercase before group/compare — Seen in: 3 (hunt-03)
```cql
| lower(field=$FIELD, as=$FIELD)     // CQL = is case-sensitive; normalize so "ServiceSectigo" == "servicesectigo"
```

### E4 — `rawContains` · Field-agnostic raw match — Seen in: 9 (clickfix-mshta, hunt-02)
Immune to field-name/attribution gaps (the `detections`-repo problem) and to per-tenant USB field naming.
```cql
| @rawstring=/$TERM/i        // /mshta/i ; /(flipper\s*devices|VID_0483&PID_(5740|DF11))/i
```
- Use as a coverage-closer ("does ANY record reference X?") and to discover which real field carries the value.

### E5 — `lookupMatch` · Enrich/restrict via lookup file — Seen in: 3 (hunt-05)
```cql
| match(file="$FILE.csv", column=$COL, field=$FIELD, mode=glob, ignoreCase=true, include=[$COLS])
```
- `strict=true` (default) keeps only matches **and** appends the lookup columns (`tool`, `fp_risk`, `note`…). Negative form `!match(...)` = ignore-list (the playbook's service-account suppressor). Powers the 819-indicator LOLRMM hunt.

### E6 — `caretTolerant` · De-obfuscate caret-escaped commands — Seen in: 5 (clickfix-cmd)
```cql
| CommandLine=/f\^*i\^*n\^*g\^*e\^*r/i      // matches finger AND f^^i^^n^^g^^e^^r
| CommandLine=/\w\^+\w/                      // any caret wedged between word chars = high-signal Run-dialog obfuscation
```

---

## F. Aggregations

Collapse events into one row per entity. Always `limit=20000` on `groupBy` (truncation-safe; pitfalls #3/#14).

### F1 — `timespan` · first_seen / last_seen per entity — **Seen in: 41 (the universal aggregation)** *(playbook §6)*
```cql
| groupBy([$ENTITY], function=[
      count(as=$COUNT),
      min(@timestamp, as=first_seen),
      max(@timestamp, as=last_seen)
   ], limit=20000)
```
- **Caveat:** `first_seen` in a short window ≠ genuinely new (pitfall #6).

### F2 — `distinctHosts` · Prevalence by distinct `aid` — **Seen in: 26**
```cql
count(aid, distinct=true, as=hosts)      // also seen as host_count / distinct_hosts
```
- Count **`aid`, never `ComputerName`** (names get reused). Low host count = lead; fleet-wide = baseline.

### F3 — `carryContext` · Sample supporting fields into the row — **Seen in: 33**
```cql
collect([$FIELDS], limit=$N)             // [ComputerName, UserName] ; [ParentBaseFileName, CommandLine] ; [LogonType]
```
- **Watch:** `collect()` only samples `limit=N` per row — a huge top row hides its tail. To clear a tail, switch from sampling to grouping the full population (hunt-03 q06→q07).

### F4 — `uniquenessSurface` · One row per exact command line — Seen in: clickfix, youngsl
```cql
| groupBy(CommandLine, function=count(ComputerName, distinct=true, as=host_count), limit=max)
| sort(host_count, order=asc)
```
- Identical commands collapse; rare/novel command lines (host_count=1) float to the top — where novel ClickFix hides.

### F5 — `hostHeadline` · Two-step distinct-host count — Seen in: 1 (youngsl-q10), reusable
```cql
| groupBy(aid, function=count(as=execs), limit=20000)   // one row per host
| count(as=distinct_hosts)                              // …then count the hosts
```

### F6 — `timeChart` · Volume over time — Seen in: youngsl-q4 (commented), playbook §6
```cql
| timeChart(span=$SPAN, function=count(as=events))      // 1d liveness; 1h heartbeat; gap-then-return / reimage detection
```

---

## G. Output — sort + humanize

### G1 — `rareFirst` vs `topFirst` · Hunting sort — **Seen in: 27 ascending**
```cql
| sort($METRIC, order=asc, limit=$N)     // HUNT: rarest/anomaly floats to the top
| sort($METRIC, order=desc, limit=$N)    // BASELINE/tuning: see what benign noise dominates
```
- The deliberate inversion is a core hunting move: rank by prevalence **ascending** (or by `successes` ascending in D2) so single needles surface instead of dropping off the capped output.

### G2 — `humanizeLast` · formatTime after sorting — **Seen in: 34** *(the example in the request; playbook §6 + pitfall #18)*
```cql
| sort(first_seen, order=asc, limit=$N)          // sort on the NUMERIC epoch first
| formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, as=first_seen, timezone="$TZ")
| formatTime("%Y-%m-%d %H:%M:%S", field=last_seen,  as=last_seen,  timezone="$TZ")
```
- **Params:** `$TZ` = `"UTC"` (default) ↔ `"America/Detroit"` (local Eastern). Toggling tz is the single most common edit.
- **Why last:** `table()`/raw `@timestamp` is epoch **ms**; humanize before sorting and the sort breaks / buckets are meaningless (pitfall #18).
- **Assignment variant:** `| first_seen := formatTime("%Y-%m-%d %H:%M:%S", field=first_seen, timezone="UTC")`.

---

## H. Discovery & false-zero guards

Defensive blocks that keep a hunt honest. (Lessons-learned §2.)

### H1 — `wideNetTable` · Field discovery — **Seen in: 18**
Project many candidate field names; empty columns simply drop out, revealing which actually populate (especially in `detections` where host/user fields are non-obvious).
```cql
| table([@timestamp, aid, ComputerName, Hostname, device.hostname, UserName, UserSid, LocalIP,
         SeverityName, Tactic, Technique, $MORE_CANDIDATES], limit=20000)
```

### H2 — `enumField` · List a field's distinct values — playbook §5
```cql
#repo=$REPO
| groupBy($FIELD, function=count(as=event_count), limit=20000)
| sort(event_count, order=desc, limit=200)
```
- Ground a filter in reality before trusting it: platforms, event types, repos, coded enums. *Which values never appear* is as informative as the counts.

### H3 — `falseZeroGuard` (convention) · Prove a zero is real
When a query returns 0 rows, **don't conclude "clean."** Check, in order: scope (repo/`All`, time picker) → field name (`#` tag, pitfall #13) → value shape (decimal vs hex, case, args-only #17) → group caps. Confirm with a no-filter `wideNetTable` (H1) before clearing a host. Codified inline in youngsl-q00/q08.

---

## Composition example

A typical hunt query = blocks A→G stacked. youngsl-q09 ("suspicious cmd on the replacement host") is literally:

```
A1 winProcEvents  →  B5 pinHost(aid)  →  B1 procIs(cmd)  →  C1 dropBenignCmd
   →  D1 flagBlocked  →  F1 timespan + F2 distinctHosts + F3 carryContext (groupBy CommandLine)
   →  D1 verdictRanBlocked  →  G1 rareFirst/recent  →  G2 humanizeLast
```

Build the library and that query becomes a one-line composition instead of 30 hand-copied lines.

---

## What to formalize first (suggested priority)

Ranked by reuse × error-proneness (the blocks where copy-paste drift bites hardest):

1. **A1 `winProcEvents`** (44 uses) — one definition kills the `Win`/`Windows` + Synthetic/Blocked false-zero class permanently.
2. **G2 `humanizeLast`** (34) + **F1 `timespan`** (41) — almost every query ends with these; trivial to make a 1-liner with a `$TZ` arg.
3. **C1 `dropBenignCmd`** (6 but highest-risk) — the args-only prefix bug (#17) is exactly the kind of subtle regex that should live in *one* tested place.
4. **D1 `flagBlocked`/`verdictRanBlocked`** (4) — encodes the "no blocks ≠ no attack" lesson; high value as a standard verdict column.
5. **F2 `distinctHosts`** (26) + **G1 `rareFirst`** (27) — the prevalence-triage pair; cheap to standardize, used constantly.
6. **E5 `lookupMatch`** (3) — already the cleanest block; promote `rmm_indicators.csv` to a permanent lookup and the LOLRMM hunt is a two-liner.

> **Platform note for actually building these.** CQL doesn't have user-defined macros the way SPL does; the practical homes are **saved searches** (referenced via `$function()` / saved-query include) and **parameterized saved searches / dashboard widgets** with `?param` inputs, plus **lookup files** for the big indicator/allowlist sets (A,C,E,F especially). The scope/verdict/format blocks (A1, D1, G2) are best as saved-search functions; the noise lists (C4, E5) as lookups. See playbook §8 "query factory."
