# NG-SIEM Hunt Notes & Lessons Learned (oakgov)

*Working reference distilled from hands-on hunting in Falcon Next-Gen SIEM. Pairs with `crowdstrike-query-playbook.md`. Update as the environment and your process evolve.*

> **Guiding principle — write for the human at the terminal.** The goal is to be human-understandable and to increase human understanding and knowledge. Hunt steps should be as understandable as possible: each step says what it's testing and what a result would mean. Don't add fluff for fluff's sake — but where there's a trade-off, bias toward the person doing the hunt, not the AI doing the work.

---

## 1. Environment cheat-sheet

### Repositories (pick from the `All` / database-icon dropdown: Falcon · Third Party · Risks)

| Repo | What's in it | Notes for hunting |
|------|--------------|-------------------|
| `base_sensor` | Endpoint sensor telemetry (~635M events) | The firehose. **Always scope** with `event_platform`, `event_simpleName`, time. Never `groupBy` it unfiltered. |
| `detections` | Falcon detections/alerts | **Multiple record shapes per detection** (HUNT-15): one shape carries `aid`/`UserName`/`user.name` with `Tactic`/`SeverityName`/`DetectName` empty; another carries `Tactic`/`Technique`/`Objective`/`SeverityName` with host/user fields empty. An `aid` filter alone may not see every record of a detection — corroborate host-level negatives from `base_sensor`. |
| `okta` | Okta system log (IdP, ~715K) | Normalized fields populate well: `event.action`, `event.reason`, `network.application`, `user.name`. Primary identity-hunt source. |
| `cisco_duo_mfa` | Duo MFA | Low volume; MFA angle. |
| `risks` | Exposure/risk findings | Vulnerability/risk context. |
| `xdr_indicatorsrepo` | XDR indicators | IOC context. |
| `3pi_auto_raptor_*`, `3pi_connection_*` | Third-party ingest | Several large; identify source before trusting fields. |
| `sensor_metadata`, `fusion` | Sensor/SOAR metadata | Small. |

### Identity (Okta) facts
- IdP is **Okta**; heavy SSO to Microsoft Office 365, Workday, Telestaff, Bookmark App, Adobe, etc.
- On `app.oauth2.*` events, **`user.name` is the OAuth client/app ID (`0oa…`)**, not a person. Resolve via Okta Admin → Applications (`/admin/app/.../instance/<id>`) or `GET /api/v1/apps/{id}`.
- On delegated AD-agent auth **failures, `user.name` = `system@okta.com`** and the real target account is embedded in `event.reason` text (`...for client=<acct>@OAKLANDMI.NET`). Extract with regex to rank targets.
- App friendly names + attempted redirect URIs + geo/IP live in the **raw event** (`target[]`, `actor`, `debugContext`) — use the Source Events tab or add the fields.
- **The tenant is a federated, multi-tenant IdP.** Logins/failures legitimately span oakgov **and** many partner orgs — townships, the Road Commission (`rcoc.org`), school districts, courts, neighboring counties (`@lyontwp.org`, `@romi.gov`, `@troymi.gov`, `@lenawee.mi.us`, `@shiawassee.net`, etc.). Consequence: one egress IP with **hundreds of distinct users failing is almost always a NAT gateway, not a sprayer**. Enrich IP ownership before escalating breadth.
- **Confirmed `okta` fields:** outcome is the tagged field **`#event.outcome`** with **lowercase** values `success` / `failure` (not `event.outcome.result` / `FAILURE`). Source IP populates on both `client.ip` and `source.ip` for interactive `user.authentication.*` / `user.session.start` events.
- **IP ownership reference:** see `Network-knowledge.md` for known oakgov egress, partner gateways, and cloud/CDN infra — check it first so you don't re-investigate friendly NAT.

### Network-adjacency telemetry: gateway MAC & the neighbor table (confirmed HUNT-18, 2026-07-12)

Two high-reuse facts. Both were *found*, not assumed — neither field appears in any projected column, and the gateway MAC is not where the FDR schema led us to look.

**1. `LocalIpAddressIP4` carries the endpoint's DEFAULT GATEWAY MAC — in the RAW event.**

The field is `DefaultGatewayPhysicalAddress`, and it lives in `@rawstring` on `#event_simpleName=LocalIpAddressIP4` in `base_sensor`. It is **not** in `sensor_metadata` (the first guess), **not** in Discover-only, and **not** in any `table()` column — a wide-net projection of `GatewayIP`/`GatewayMAC`/`MAC`/`MacPrefix` returns nothing. It surfaced only because a discovery query projected `@rawstring` and someone read it.

```cql
// what is this host routed THROUGH?  (value shape: dash-separated, UPPERCASE)
#repo=base_sensor event_platform=/^Win/i
| in(field="#event_simpleName", values=["LocalIpAddressIP4"])
| regex("(?i)\"DefaultGatewayPhysicalAddress\"\\s*:\\s*\"(?<gw_mac>[0-9A-F]{2}(?:[:\\-][0-9A-F]{2}){5})\"", field=@rawstring, strict=true)
| lower(field=gw_mac, as=gw_mac)
```

- **Why it matters far beyond one hunt:** this answers *"what is routing this endpoint's traffic?"* — rogue/consumer gateways, shadow-IT routers, hotspot tethering, AiTM position. HUNT-18 used it to prove 7 county laptops sit behind backdoored consumer routers. Any "is this asset on gear we control?" question starts here.
- **Caveat — it fires on IP-assignment CHANGE, not continuously.** `observations` counts network-hopping, not exposure duration. Absence of a row does not mean the host left the network. Never quote its `first_seen` as an exposure start; get duration from neighbor telemetry instead.
- **Companion field on the same event:** `PermanentPhysicalAddress` = the host's own **burned-in** NIC MAC (survives spoofing of the operational address). A foreign OUI here means foreign hardware *inside* the machine — HUNT-18 caught a USB Wi-Fi dongle this way.
- **Hex-collision warning:** always anchor the regex to the **key name**. A bare 6-hex OUI match against `@rawstring` hits GUIDs and `"id":"…"` fields — 119 of 198 rows in HUNT-18's first pass were exactly this noise.

**2. `NeighborListIP4` packs its neighbors into ONE delimited string — and the NAME is not the device's.**

Shape, confirmed in-tenant: **`MAC|IP|flag|Name;`** repeated per neighbor, **dash-separated, UPPERCASE**, many neighbors per event. There is no scalar MAC field — an equality filter finds nothing; you must regex the packed string. (Lens is healthy: 93.3M events / 10,133 Win hosts / 1y.) Unresolved names appear as `!!!!UNKNOWN!!!!`.

> **The trap: the 4th field is the REPORTING host's NetBIOS/LLMNR resolution of that IP — not a self-announcement by whatever owns the MAC.**

So when a MAC and a hostname disagree, believe neither blindly. A consumer **repeater/extender in client-bridge mode performs MAC translation** (802.11's three-address framing can't carry the original client MAC through a wireless bridge), so it presents *every device behind it* using **its own MAC**. HUNT-18 saw one Tenda MAC (`04-95-e6-24-9c-01`) front **23 IPs and five personal machines** — `JEFFS-LAP-2022`, `LUCAS-LAPTOP`, `DESKTOP-VQBRMT1`… all real hosts, all wearing a router's MAC in the ARP table.

**Rule: the MAC identifies the bridge; the name identifies who is behind it.** One MAC fanning out across many IPs and many hostnames over a long window is the *signature* of a bridge — not DHCP churn (transient, one-off) and not MAC randomization (which sets the locally-administered bit and so can never collide with a real vendor OUI).

### Known-baseline browser command-line patterns (confirmed HUNT-10, 2026-07-03)

For any detection keyed on Chromium (`chrome.exe`, `msedge.exe`) launch flags — `--headless`, `--load-extension`, `--user-data-dir`, `--disable-sync`. Use these fingerprints as exclusions before alerting.

| Pattern | Parent | Where it shows up | Meaning |
|---|---|---|---|
| `chrome.exe --disable-features=LoadLowEngagementPEHFeaturesToPrefs --headless=new --no-first-run --noerrdialogs [--origin-trial-disabled-features=CanvasTextNg\|WebAssemblyCustomDescriptors] --user-data-dir="…\Temp\scoped_dir<PID>_<rand>" [--restore-last-session --restart]` | `chrome.exe`, `platform_experience_helper.exe`, or `explorer.exe` (see accounting quirk) | fleet-wide — 1,600+ users, ~7,400 hits/30d for the PEH parent alone | Chromium's own **PEH self-probe** — Chrome spawns this at launch to evaluate Persistent Engagement Hint feature state. Benign. Dominant noise source for any headless-flag rule. |
| `chrome.exe --proxy-server=localhost:8080 --ignore-certificate-errors "--user-agent=…" --user-data-dir=…\Temp\burp<N>.tmp --load-extension=…\AppData\Roaming\BurpSuite\{new-tab,navigation-recorder,dom-invader}` (plus many `--disable-*` / `--no-*`) | `BurpSuite.exe` | authorized IT staff (attested: Terry Waller / `wallerte` on NB239211) | Burp Suite Pro embedded Chromium loading Burp's own shipped extensions. Benign for authorized users; the `--proxy-server=localhost:8080` + Burp `AppData\Roaming\BurpSuite\...` extension paths are the high-precision tell. |
| `chrome.exe --headless …` | `RoutingEngineServiceHost.exe`, `w3wp.exe` | `OCG-LF-*FRMS-*` servers; `w3wp.exe` runs as `FormsAppPool` | Laserfiche Workflow / Forms server-side render (PDFs, form output). Benign. |
| `chrome.exe --headless …` | `node.exe` | `OCA-PMO-APP-1P` (PMO app server) | Puppeteer/Playwright dev automation. Benign. |

**`explorer.exe → chrome.exe --headless` accounting quirk (HUNT-10 F4):** when a user launches Chrome from the taskbar/Start Menu shortcut, the PEH self-probe (headless helper) can be attributed to `explorer.exe` as the parent rather than the intermediate `chrome.exe`. Process rollup consolidates the short-lived browser process. In HUNT-10 this produced 40 explorer-parented `--headless=new` events across 38 users, all carrying the identical PEH fingerprint. Not a shell-integration attack — a rollup artifact. Treat as baseline.

---

## 2. Gotchas that cost time (check these first)

1. **CQL `=` is case-sensitive.** Lowercase `"0xc000006a"` matched nothing. Use the exact case, or `=/pattern/i` when unsure.
2. **Stored value format ≠ display format.** Windows `SubStatus` is stored as **decimal** (`3221225578` = `0xC000006A`, bad password). Confirm the actual value (run a discovery `table()`) before writing an equality filter. Convert with `format("%x", field=…)` if needed.
3. **`groupBy` caps:** default **20,000 groups** (extras discarded) and **200 output rows**. Add `limit=20000` to `groupBy` and `limit=N` to `sort`, or use `top()`. Real fix is usually to **scope tighter** so you aren't grouping the firehose.
4. **Field names differ by repo/parser.** Normalized fields (`event.action`, etc.) populate on third-party data (Okta) but not raw sensor events; sensor fields (`event_simpleName`, `ComputerName`) don't exist in third-party repos. Always verify per repo.
5. **Empty columns just vanish** from `table()` output. Use a **wide-net `table([...])`** with several candidate field names to discover which actually populate, or scan the **Filter fields** panel (fill %).
6. **`first_seen` within a window ≠ genuinely new.** A 7-day `min(@timestamp)` only means "first seen in the last 7 days." For true "new app/account," hunt lifecycle/creation events or compare against a longer baseline.
7. **Empty geo/IP on back-channel events.** OAuth `token.grant` rows are server-to-server (no client context); geo/IP populates on the interactive `authorize` rows.
8. **FQL ≠ CQL.** SIEM search = CQL; Falcon API filtering = FQL. Don't mix syntaxes (see playbook).
9. **"No prevention blocks" ≠ "no attack."** This trap recurred three times in one investigation. The ClickFix **RAN** — detected-but-not-prevented — so an empty `ProcessBlocked` result told us nothing. Assess a host through the **detections stream + a suspicious-cmd sweep**, never the blocks query alone. (Keep `ProcessRollup2 OR Synthetic OR ProcessBlocked` in process sweeps so a prevented run can't false-zero either.)
10. **`base_sensor` retention is AT LEAST 12 MONTHS — not ~24h, not ~30d.** Corrected twice. HUNT-07 said ~24h (wrong); HUNT-08 said ~30d (also wrong — that was just the default picker). **HUNT-16 pulled `ProcessRollup2` back to 2025-07-11 and joined bind events to process starts from mid-2025** — a full year, on ordinary workstations, across process/bind/scheduled-task/file families. **Set the picker deliberately; ~30d is a habit, not a limit.** This matters more than it sounds: HUNT-16's entire finding (a nightly capture job that ended 2025-12-18) sat *outside* the 30d window that generated its own trigger. When a hunt is about *capability* or *staging* rather than a live payload, default to 1y.
11. **`sort asc` + row cap = oldest-slice illusion (inverse of pitfall #15).** A truncated 20k-row export sorted ascending covered 06-02→06-30 and silently *stopped before the windows of interest* while looking like a complete month. Default to `sort desc` when truncation is possible, and treat row-count == limit as "truncated" every time.
12. **`InstalledBrowserExtension` field names (confirmed):** `BrowserExtensionId`, `BrowserExtensionName`, `BrowserExtensionVersion`, `BrowserExtensionInstallMethod`, `BrowserProfileName`. `BrowserName` is a coded enum: **3=Chrome, 4=Edge** (empirical). `InstallMethod` observed {0,1,2} — 1=browser defaults, 2=user/store installs, 0 seen on policy-pushed Trellix (legend TBC). **HUNT-13 re-confirmed on a real inventory:** 1 = vendor default/component (Chrome Web Store Payments, Google Docs Offline, Edge components), 2 = user/store install (uBlock, Adobe, Dark Reader — and the rogue "Save ChatGPT") → **method 2 is the bucket a rogue install hides in**, 0 = `no-extension-available` placeholder row. Generic names (`ExtensionId`, `ExtensionName`) silently vanish from `table()`.
13. **MFA-push source IPs are the phone, not the workstation.** Okta `auth_via_mfa` rows log the *approving device's* egress — near-daily carrier-NAT successes (T-Mobile `172.32.0.0/11`) at shift start are the expected shape of Okta Verify pushes, not anomalous access.
14. **Per-tuple `groupBy` + sort cap silently drops entire categories.** HUNT-10 Q4 grouped `--headless` events by `[ComputerName, UserName, ParentBaseFileName, FileName]` and hit the 200-row sort cap; two parent processes (`explorer.exe`, `BurpSuite.exe`) sat below the cap and were invisible. Q5 collapsed the group key to `ParentBaseFileName` alone (with `distinct=true` counts for hosts/users) and revealed them. **Rule:** when enumerating the *universe* of a categorical dimension (all distinct values in a column), strip tuple explosion before you group — otherwise a rare category with few tuples gets buried under the sort limit. Companion to pitfall #3 (group caps). Snippet: see §5 "airtight-tail" template.
15. **The detection card's CommandLine is the launch args, not the matched object.** For file-creation custom IOAs the console shows how the *triggering process* was started; the file that actually matched the rule lives only in the raw event (`CustomIOAFileWrittenDetectionInfoEvent.TargetFileName`). Pull the raw event before theorizing — HUNT-15's "why did a DLL-open fire a JS rule?" dissolved the moment `TargetFileName` showed `Downloads\new 25.js`.
16. **`PromiscuousBindIP4` / `RawBindIP4` carry NO process name — only `ContextProcessId`.** Confirmed HUNT-16: the events populate `aid`, `ComputerName`, `ContextProcessId`, and socket fields (all `0.0.0.0:0` at bind time). `ContextBaseFileName`/`ImageFileName`/`UserName` are **empty**, so they silently vanish from `table()`/`groupBy()` output (gotcha #5) and a `groupBy([#event_simpleName, ContextBaseFileName])` collapses the whole fleet into one identity-less mega-row. **To name the binder, join `ContextProcessId` → `ProcessRollup2.TargetProcessId` on the same `aid`** (sensor process ids are per-aid unique — no OS-PID-reuse trap). Working query: `hunt-16-promiscuous/query-04.txt`. Same attribution gap applies to **`*FileWritten` events** (`UserName`/`ContextBaseFileName` empty on ~99% of rows).
17. **npcap packet capture does NOT emit `PromiscuousBindIP4` — the effect event is blind to the effect.** npcap sets promiscuous mode at the **NDIS driver layer**; `PromiscuousBindIP4` is winsock/`SIO_RCVALL`-shaped. HUNT-16 proved this the hard way: 160 confirmed `dumpcap -w` runs, plus dozens of live Wireshark captures on domain controllers, produced **zero** promiscuous-bind events. Fleet-wide the *only* promiscuous binder is `svchost.exe` (OS baseline, ~5,900 hosts). **Corollary to playbook Use Case 11 ("prefer the native effect event"): prove the effect event fires for a KNOWN-TRUE case before you trust its silence.** An authoritative-looking event that never fires is worse than no event — it manufactures confident false negatives.
18. **pcap output does not register in file-write telemetry either.** Same hunt: those same 160 `-w C:\drop.pcap` runs produced **zero** `*FileWritten` events. Only an explicit Wireshark *Save-As* (`GenericFileWritten`) showed up. **Capture is detectable in this tenant by process execution and essentially nothing else.** Also: **`.cap` is predominantly NOT a packet capture** — it's UEFI/BIOS firmware capsules (Dell R740, ASUS, Lenovo), AMD driver files (`atiumd6a.cap`), and AV pattern files. Any `.cap` rule needs that exclusion set or it drowns.
19. **`sort(order=asc)` is NOT "rare-first" when the tail is a wall of ties — and the row cap then hides the answer.** HUNT-18 Q05 enumerated gateway-MAC OUIs with `sort(endpoints, order=asc, limit=500)`, expecting rare vendors on top. It returned **exactly 500 rows — the cap — every single one `endpoints=1`, and ZERO Tenda.** The zero was **false**: a prior query had already proven 7 Tenda-gateway hosts in that very field. Cause: hundreds of OUIs tie at `endpoints=1` (401 of the 500 were **locally-administered/randomized MACs** — first octet's 2nd nibble ∈ {2,6,a,e}: `02- 06- 0a- 0e- 1a- 1e- 22-` — i.e. phone hotspots and virtual adapters), so the ascending slice returned an arbitrary 500 of the ties and **truncated before ever reaching `endpoints>=2`**, which is exactly where the finding lived. Ascending sort is a *hunting* instinct (G1) and it is **wrong for a distribution with a huge tie-floor**.
    - **Tells:** row count == the limit (always suspect truncation, #14/#11), *and* the sort metric is constant down the entire output. Either alone is a warning; together they are proof.
    - **Fixes, in order of preference:** (a) **don't enumerate the universe — filter straight to the hypothesis** and group per-entity (HUNT-18 Q06 did this: 7 rows, canary 7/7, no cap exposure); (b) collapse the group key to the single categorical dimension so tuple explosion can't blow the cap (the §5 "airtight-tail" template, pitfall #14); (c) prune the noise population (exclude locally-administered MACs) *before* ranking.
    - **This is the THIRD canary save in this corpus** (HUNT-15 Q03, HUNT-16 Q10/Q11) — and the first that caught **the analyst rather than the data**. The query was well-formed, the field was right, the value shape was right; the *ranking strategy* silently ate the answer. **A negative without a canary is indistinguishable from a broken filter — and now also from a badly-sorted one.**
20. **A trigger inherits the blindness of the query that generated it.** HUNT-16's trigger came from the shell-spawning-parent inventory (`hunt/cmd/query-03`), which only sees installers that spawn a shell — so it surfaced npcap 1.85/1.87/1.88 but was structurally incapable of seeing npcap 0.9989 (an old Wireshark bundle on a server), which appeared the moment we queried npcap directly. **When adopting a trigger from an existing query, ask what that query cannot see, and re-derive the population from first principles.**
21. **ASEP registry events don't populate `UserName` in this tenant — attribute via the PID pivot.** The persistence hunt (`proc/query-04`, export-reg) grouped `AsepValueUpdate` / `RegGenericValueUpdate` writes and `UserName` came back empty on 999/1000 rows — the same identity gap as `PromiscuousBindIP4` (#16) and `*FileWritten`. `ContextProcessId` *is* present; resolve the writing process image + user by joining `ContextProcessId → ProcessRollup2.TargetProcessId` on the same `aid` (per-aid-unique pids). Scope the subquery to the hit `aid`s so you don't push the ProcessRollup2 firehose through the join, and set the picker LONG — a persistence writer's process start can predate the registry write by months. `ContextBaseFileName` *may* populate on some reg events — wide-net a raw event first (#5); if it does, you skip the join.
22. **IFEO registry writes are dominated by exploit-MITIGATION config, not `Debugger` hijacks — always constrain IFEO to `RegValueName=Debugger`.** In export-reg, 100% of `Image File Execution Options` writes were `MitigationOptions` / `DisableExceptionChainValidation` / `FrontEndHeapDebugOptions` set by EDR/apps (e.g. SentinelOne's `SentinelMemoryScanner.exe`) — **zero** `Debugger` values. A hijack/persistence hunt keyed on the IFEO *key* drowns in benign mitigation config; the only persistence-relevant IFEO value is `Debugger` (with `GlobalFlag` + `MonitorProcess` as the silent-process-monitor pair). Same value-vs-key trap as `AppInit_DLLs` — a *value* under `…\CurrentVersion\Windows`, not a key-path segment, so a `RegObjectName` regex misses it. Broader lesson from the same hunt: a raw ASEP sweep is a **census** of benign auto-starts (WiX `\ProgramData\Package Cache\` installer cleanup, `advpack.dll,DelNodeRunDLL32` self-extractor cleanup, BeyondTrust/Bomgar RMM → `clemis.org\sra-pin.exe`), not a detection — classify by *value shape* (script host / encoded / net / user-writable path) and subtract the sanctioned baseline before ranking. Tuned query: `proc/query-04.txt`.
23. **On-Demand-Scan / AV quarantine detections are NOT in the `detections` repo — and don't answer to `@rawstring`.** (INFO.EXE removable-media hunt, 2026-07-19.) An `OnDemandScanMLFileAnalysisHigh` quarantine never appeared in `#repo=detections` (aid + hash + IOA-name all zero). ODS/EPP AV verdicts land in **`base_sensor`** as their own event families: **`OdsMaliciousFileFound`**, **`QuarantinedFile`**, **`QuarantinedFileState`** (with `OdsStarted` / `OdsStatus` / `OdsActionStatus` as the per-scan lifecycle). Worse, a rawstring IOC hunt across `base_sensor` **also** false-zeroed — these low-volume sensor events **do not expose the hash or path through `@rawstring`** the way process events do, so `@rawstring=/<sha256>/i` returns nothing even though the record exists. What worked was the §4 false-zero drill: strip the filter, `groupBy(#event_simpleName)`, read which family carries the file. **Confirmed fields** on `QuarantinedFile` / `QuarantinedFileState`: `FileName`, `FilePath` (device-path form, e.g. `\Device\HarddiskVolume8\Recycled\`), `SHA256HashData`, `IsOnRemovableDisk` (`1`=removable), `DetectName`, `DetectDescription`; `VolumeName` is **empty** on these (the volume is embedded in `FilePath`). To locate any AV/ODS detection, hunt the **event family**, not the repo and not the rawstring. Corollary: **pivot from the sensor's recorded `SHA256HashData`, not a hash transcribed off the console screenshot** — in this hunt the two differed by two characters, so a hash-only query built on the screenshot value would silently false-zero regardless of ground truth.
24. **An on-demand-scan detection is a file-AT-REST verdict, not evidence of execution.** (Same hunt.) `OnDemandScanMLFileAnalysisHigh` (ODS/AV ML quarantines generally) fires when a file is *scanned on disk*, not when it runs — so "a detection fired on host X" does **not** mean the malware executed, or was even written, there. INFO.EXE never ran (no `ProcessRollup2` / `Synthetic` / `Blocked` by hash, fleet-wide 90d), was never written locally (no `*FileWritten` / `FileCreateInfo`), and existed only as a quarantine record on a **removable** volume (`IsOnRemovableDisk=1`, `\Device\HarddiskVolume8\Recycled\`). It rode in on a USB stick that a scanning / "sheep-dip" workstation auto-scanned on insert — each `DcUsbDeviceConnected` → `OdsStarted` within ~1-2s, and the malicious hit sat between the drive's mount and unmount (Kingston DataTraveler 2.0 connected 04:00:05 → `RemovableMediaVolumeMounted` HarddiskVolume8 04:00:06 → `OdsMaliciousFileFound` / `QuarantinedFile` 04:00:11 → `FsVolumeUnmounted` 04:00:31). **Prove execution independently before treating an ODS/AV detection as a compromise** — pivot the hash to `ProcessRollup2` (ran?) and `*FileWritten` (landed locally?); a scan verdict alone is consistent with a file caught doing nothing. **Removable-media telemetry note:** the *mount* of a USB volume is logged as **`RemovableMediaVolumeMounted`** (carries `VolumeName=\Device\HarddiskVolumeN`, `IsOnRemovableDisk=1`, `ContextProcessId`), **not** `MountedVolume` / `FsVolumeMounted` — so a USB timeline built only on those families catches the `FsVolumeUnmounted` but **misses the mount** (exactly what happened in export-06: HarddiskVolume8 showed only the dismount). Include `RemovableMediaVolumeMounted` to see removable mounts.
25. **Chrome-attributed `DnsRequest` rows routinely omit answer IPs — answer-absence is NOT non-resolution.** (HUNT-22, 2026-07-22.) On the day of the hunt, every external chrome lookup carried empty `FirstIP4Record`/`IP4Records` — including domains that certainly resolve (googleapis, safelinks itself) — while OktaVerify, svchost, node, and powershell rows filled answers normally; on other days chrome partially fills (cause unresolved: async-DNS/DoH mix suspected). Cost: an early "domain never resolved — confirmed" claim had to be retracted when the audit showed its supporting canary was an OktaVerify row, not a chrome row. **Prove non-contact at the connection layer (`NetworkConnectIP4/6`), never from DNS answer fields** — and before trusting the answer fields at all, check fill-rate per `ContextBaseFileName` (wide-net a sample and count rows with vs without answers) so a per-process gap can't masquerade as NXDOMAIN.
26. **`EppDetectionSummaryEvent` context arrays carry process-START context, not alert-time context.** (HUNT-22.) The Intel Detection's `DnsRequests[]` / `NetworkAccesses[]` timestamps were ProcessStartTime+2s (08:35 ET) while the alert fired at 12:04 — 3.5 hours of drift on a long-lived browser network-service process. The detection record's (and console card's) "DNS requests / network connections" describe the process's *birth*, not the detected moment. Compare `LoadTime`/`AccessTimestamp` against `ProcessStartTime` before treating those arrays as what-was-happening-at-alert-time browsing context.
27. **Chrome's network service is an attribution ceiling — and link clicks can be process-invisible.** (HUNT-22.) Every tab and extension resolves and connects through one utility process (`--utility-sub-type=network.mojom.NetworkService`), so DNS and connection telemetry bottom out at "chrome did it." A parent-agnostic sweep of URL-bearing browser launches over the 2-day window returned only crashpad-handler noise (`--url=https://clients2.google.com/cr/report` — itself a useful cold-start + version marker): every link click on the host, including three wrapper-proven email clicks, happened *inside* the browser and spawned nothing. Ways to get closer anyway: renderer-spawn timing (a new renderer = a new page/site instance, including cross-origin ad iframes), first-contact connection sequencing against the DNS moments, and **reverse-by-answer** — name a connection IP from ANY host's/process's recorded answers fleet-wide (HUNT-22 Q14 named a shared-hosting vhost, the Font Awesome CDN, and Chrome's own `e2c2.gcp.gvt2.com` in one query).
28. **Verify the assumed actor process EXISTS before trusting a lineage query's zero.** (HUNT-22.) The outlook→browser favorites query returned a clean zero that was structurally meaningless: `OUTLOOK.EXE` hadn't run since six days before the window — mail on that host is OWA in Chrome (`outlook.cloud.microsoft` in MOTW referrers), and New Outlook is `olk.exe` besides. The zero was caught only because the operator knew a `url.avanan.click` lookup means an email link WAS clicked, so the instrument itself had to be broken. Two rules: a cheap process-census of the assumed parent (90d, `ProcessRollup2`+`Synthetic`+`Blocked`) precedes any lineage negative; and **domain knowledge that predicts a positive is a canary for the INSTRUMENT, not just the filter.**

---

## 3. Open threads / leads to revisit

> Status as of this session — treat as **leads needing validation**, not conclusions.

- **Password spray — HUNTED & DISPROVEN (2026-06-22).** ThreatInsight's spray signal was dispositioned over 30d: the failure breadth traces to federated NAT egress (oakgov + partner gateways), no hostile external IP produced multi-user success (broad landing), and no account showed fail-then-success from an unrelated/hostile shared IP (low-and-slow landing). Residual: small agentless-IWA username enumeration against shared accounts (`PR-DRWR-*`, `*tech*`) + stale-cred/lockout loops. Full writeup: `hunt-report-okta-password-spray-2026-06-22.md`. Caveat: rules out *spray* landing, not a clean phished-cred login that left no failure trail.
- **OAuth client `0oa88jltc4ea35k4B357`.** High volume of `illegal_redirect_uri_enhanced` *interleaved with successful* token grants and `user_claim_evaluation_failure` → looks like a **misconfigured legit integration**, not pure probing. Confirm app identity, compare attempted vs registered redirect URIs, check source geo/IP. See `okta-redirect-uri-hunt-brief.md`.
- **`ServiceWSUS_CLM` service account** failing LogonType 3 (network) bad-password → classic **stale cached credential** (service/scheduled task) — also a lockout risk. Find originating hosts, update the stored credential.
- **`detections` repo attribution gap.** Find the real host/user field names so Privilege Escalation (and other) detections can be actioned, not just counted.
- **Privilege Escalation baseline.** 52 detections, all `Valid Accounts / Gain Access / Informational`. Low urgency, but build the who/where summary and watch for non-admin or service accounts appearing, or escalation on unusual hosts.
- **HUNT-08 `wpforminfo.site` — HUNTED & DISPROVEN (2026-07-02).** 3 intel-domain hits on WS244937/moralesn = restored Chrome tab re-contacting a fresh fake-WPForms lure (QWINS/reg.ru infra) at each logon. No execution, no spread, no direct-IP payload, extensions clean, Okta clean. Full writeup: `hunt-08-wpforminfo/hunt-08-report-wpforminfo-2026-07-02.md`. **Residual actions pending:** clear moralesn's Chrome session state on WS244937; custom IOC block `wpforminfo.site` + `84.21.189.13`; silence at next logon = confirming test.
- **Grayware/baseline oddities parked from HUNT-08:** Capital One Shopping coupon extension on rusingm's profile (WS244937) — extension-governance question. Recurring SYSTEM `cmd→powershell` scanning `%USERPROFILE%` for conda/cargo/.local/bin across the month — looks like IT dev-tooling inventory; confirm owner.
- **HUNT-10 headless-Chromium — HUNTED & DISPROVEN (2026-07-03).** Proactive coverage hunt for Chromium launch-flag abuse (`--headless`, `--load-extension`, `--user-data-dir`, `--disable-sync` + `--no-first-run`). Golden pair (`--headless` ∧ `--load-extension`) = 0 events over 30d. Every `--headless` / `--load-extension` observation resolves to one of five benign categories: Chromium PEH self-probe (fleet-wide), Laserfiche Workflow/Forms server render (`RoutingEngineServiceHost.exe`, `w3wp.exe` on `OCG-LF-*FRMS-*`), Puppeteer/Playwright dev automation (`node.exe` on `OCA-PMO-APP-1P`), Burp Suite Pro on `NB239211/wallerte` (Terry Waller, authorized), and `platform_experience_helper.exe` OS/browser integration. Zero anomalous parents (no Office/wscript/mshta/rundll32/temp-dropper). Full writeup: `hunt-10-headless/hunt-10-report-headless-2026-07-03.md`. **Detection-engineering candidate ready:** golden-pair rule with the five exclusions above (fingerprints captured in §1 baseline-patterns table); empirically ~0/day residual after exclusions.
- **HUNT-16 npcap / packet-capture capability — HUNTED, H2 DISPROVEN, H1 PROVEN (2026-07-11).** Year-wide sweep: 29 install shapes / **84 installer executions** / **30 hosts** / 4 clean arrival channels (ThousandEyes agent OEM bundle, Wireshark bundle, Nmap bundle, standalone); one SHA256 per **build** (retail and `-oem` are different binaries — expected); ~42 operators, nearly all IT/security. **Anomaly: `WS126628` ran an unattended nightly 30-min `dumpcap … -w C:\drop.pcap` (160 runs, Jul–Dec 2025) as a scheduled task under the shared privileged account `itadmin`** — no ticket, no owner, and **no `ScheduledTaskRegistered` event in a full year (task predates retention → not attributable from telemetry)**. Host decommissioned 2025-12-18; fleet sweep confirms the job did **not** relocate. Full writeup: `hunt-16-promiscuous/hunt-16-report-promiscuous-interface-2026-07-11.md`. **Residual actions:** (1) WS126628 owner/asset record + confirm disk wiped + what segment `-i 4` saw; (2) **shared privileged accounts running capture — `ITAdmin` (13+ endpoints, ran the job) AND `Administrator` (~131 capture executions across 4 Emergency-Management hosts) → IAM governance review**; (3) change records for netadmin24's Wireshark captures on **3 domain controllers** (INF-AD-1P/2P/3P, 2026-05-26 — **plus a repeat on INF-AD-3P 2026-06-04**; behaviorally benign, hands-on-keyboard); (4) retire stale Wireshark **3.2.3 (2020, three hosts, shared old copy)** / **3.6.0 (2021)**. **Detection-engineering candidate ready:** unattended-capture rule, **tier 1 = scheduler/service parent → 1 TP / 0 FP fleet-wide over 1y**; tier 2 = shell parent → hunt queue (favorites #14). **Two blind spots proven:** npcap capture emits **no** `PromiscuousBindIP4` (NDIS layer) and pcap writes emit **no** `*FileWritten` — process execution is the only working signal. **Coverage gap:** ~22 hosts run capture tools with **no npcap install inside the window** (capability predates retention) — install archaeology can't see them. Backlog: **HUNT-17 = `netsh trace` / `pktmon` ETL capture** (captures with no npcap at all; entirely outside this hunt's lens).
- **HUNT-13 rogue Chrome extension / Sekoia supply-chain sweep — HUNTED, H1 PROVEN & CONTAINED (2026-07-04).** Swept fleet against Sekoia's Cyberhaven-cluster IOCs (7 categories). Confirmed rogue **"Save ChatGPT"** (`iccmddoieihalmghkeocgmlpilhgnnfn`, delisted, harvests FB creds) on **NB201008/grantz** (Assistant Prosecuting Attorney), tied to `savegpt[.]pro`; **blast radius = 1 host**, C2 dark since 05-22, exposure bounded ~Jan 22–May 22 2026. Sekoia's 16 supply-chain IDs present only on **patched/clean** versions (Bookmark Favicon Changer 5.2 > malicious 4.00; Reader Mode 2.0.9 > 1.5.7/clean 1.5.8) with C2 silent; all other IOC categories 0 fleet-wide. Full writeup: `hunt-13-theft/hunt-13-report-savegpt-rogue-extension-2026-07-04.md`. **Residual: remove ext + rotate grantz creds/sessions; IOC block ext-ID + `savegpt[.]pro`; hygiene-remove clean supply-chain exts on EA000034/EA000039/NB230483.** Backlog: **HUNT-14** = fleet-wide rare user-installed (method 2) extension review (catches rogue exts without a prior IOC).

---

## 4. Process lessons (my approach)

**The big one — a query without a goal isn't a hunt.** A clever query that surfaces something interesting still can't be handed off until it has: a clear **objective**, a **hypothesis stated so it can be disproven**, **benign-vs-escalate criteria**, and a **definition of done**. Define those *before* sending it to the team. (Template: `okta-redirect-uri-hunt-brief.md`.)

**The workflow that worked, in order:**
1. **Pick the language** — CQL for SIEM search, FQL for API.
2. **Find the data** — list repos (`| groupBy(#repo, …)`), select the right one. Don't hunt in `All`.
3. **Scope first** — repo + time + the single most selective filter; run it and eyeball the rows.
4. **Discover fields** — wide-net `table()` or the Filter fields panel; confirm names and value formats before equality filters.
5. **Confirm value formats** — decimal vs hex, case, prefixes.
6. **Layer, then aggregate** — add filters, project readable columns, group/aggregate on the reduced set.
7. **Interpret with context** — parent process, account type (human vs service/shared), location. Most "hits" are benign admin/tooling; the deviation is the finding.
8. **Frame for handoff** — objective, criteria, definition of done — before promoting to a saved search or rule.

**Reusable instinct:** when results look wrong/empty, suspect (in order) scope (wrong repo/`All`), field name, value format/case, then group caps — before doubting the syntax.

**More lessons from the password-spray hunt:**
- **Failures prove *attempts*; successes prove *impact*.** Spray generates failures whether it's harmless or catastrophic — the failure count can't close the hunt. Always pivot to "did anything *succeed*?" to reach a verdict.
- **`sort … limit` by a volume metric buries low-and-slow.** Ranking accounts by failure count set a hidden floor (output capped at 200 → everything under 22 failures invisible) — exactly where a slow sprayer hides. Fix: drop the volume floor and **change the unit of analysis** — group by *(account, IP)* pair, require ≥1 fail **and** ≥1 success, sort **ascending** on successes so single-success needles surface instead of dropping off.
- **Breadth ≠ spray in a federated tenant.** "Many users from one IP" is a gateway. The real takeover signature is the inverse: a *cross-org / unrelated* account cluster failing+succeeding from one **hosting/VPN/foreign** IP. Same-domain clusters on an IP = that org's NAT (benign).
- **Enrichment is the disambiguator.** A residential fail-then-success looks like an attacker until you resolve the IP. From your box: `dig -x` + `whois` (helper: `hunt/enrich-ips.sh`). From a restricted sandbox (no DNS/whois egress): `https://bgp.he.net/ip/<ip>` gives AS/owner/PTR. PTR + same-domain account cluster is the fastest benign call (e.g. `97.107.82.162` → `mail.lenawee.mi.us`).
- **Exclude `system@okta.com` from account-centric analysis** — it's the delegated-AD-agent placeholder and collapses thousands of real users/IPs into one bucket, dominating sorts.

**More lessons from the youngsl host investigation:**
- **Sequence broad→narrow.** Start with the authoritative signal and zoom in: **detections → suspicious-cmd → logon blast-radius → then filter to the host.** Leading with the detections stream tells you what Falcon already saw; narrowing afterward keeps every step scoped and readable.
- **Confirm containment with data, not inference.** "The host went quiet" is a measurement, not a guess. Run a liveness check — `groupBy(aid) | max(@timestamp)` across *all* telemetry ("no logons" ≠ offline) — then find the replacement box via `UserLogon` grouped by user (newest `last_seen`). The cutover timeline (old box last-seen, new box first-seen) corroborated the reimage.

**More lessons from the mshta / ClickFix hunt (2026-06-28):**
- **Distinguish the technique from the delivery vector.** "ClickFix" is a delivery method; T1218.005 is the technique. The hunt found the technique (ManualFinder) but not the vector (ClickFix). Keep the hypothesis precise so the verdict stays honest.

**More lessons from the HUNT-10 headless-Chromium hunt (2026-07-03):**
- **Don't inherit attribution across turns.** When an aggregate query omits the identity field (UserName / ComputerName), the identity of the underlying rows is *unknown* — even if you were just discussing a specific user two turns earlier. In HUNT-10 I incorrectly carried "Dennis Faustich" attribution from Q3's FAUSTI~1 row into my review of Q5's `BurpSuite.exe` parent-only aggregate; Q7's per-user attribution proved the actual Burp user was Terry Waller (wallerte). **Rule:** never lock attribution to a query result that doesn't carry the identity field. Say "identity unknown; next query resolves" and pivot before making claims.
- **Sanity + flag inventory before the interesting query.** When a specific-flag hunt returns zero, run a `groupBy(CommandLine)` sanity pass and extract the flag tokens across the top rows (`grep -oE -- '--[a-z][a-z0-9-]*' | sort | uniq -c | sort -rn`). Two things fall out immediately: proof that the pipeline works, and the *flag universe actually present* in the environment. HUNT-10 found `--headless=1`, `--load-extension=0` from the inventory pass alone — that framed the whole hunt.
- **Airtight-tail the universe, not the tuple.** When you need to prove "no rare exceptions," split the query into two passes: (1) tuple-level (host × user × parent × …) for the rich picture, and (2) categorical-key-only (e.g., `ParentBaseFileName` alone with `distinct=true` counts for hosts/users) to enumerate the *complete universe* of that dimension. Pass 2 defeats the sort cap and catches rare categories pass 1 buries. See pitfall #14 and the §5 snippet.
- **Sanctioned tooling produces high-fidelity fingerprints — use them for exclusions.** Burp's `--proxy-server=localhost:8080` + `--ignore-certificate-errors` + `AppData\Roaming\BurpSuite\...` load-extension paths is a much more precise exclusion than "if parent = BurpSuite.exe." Same idea for Laserfiche (`RoutingEngineServiceHost.exe` on `OCG-LF-*FRMS-*`) and Puppeteer (`node.exe` on the PMO app server). Precise fingerprints survive process-name changes and prevent broad-parent bypass.

**More lessons from the HUNT-13 rogue-extension hunt (2026-07-04):**
- **A compromised extension ID present ≠ compromised — check the installed version.** Three of Sekoia's 16 IDs were installed but on versions *newer* than the trojanized builds (auto-updated past the bad code); their C2 domains were silent. Always resolve the malicious version range, compare, and corroborate with C2-domain silence before escalating an ID match.
- **IOC lists catch the known; they miss the actor's *own* fake extensions.** The 16-ID sweep (Q04) completely missed the real victim (grantz) — his rogue extension was the actor's delisted fake ("Save ChatGPT", a *different* ID), caught only by the domain IOC (`savegpt[.]pro`, Q07) and a full inventory (Q09). Pair indicator-matching with a rare/long-tail extension review (→ HUNT-14).
- **Name-to-infrastructure correlation is a fast, strong pivot.** "Save ChatGPT" ↔ `savegpt[.]pro` on the same host cracked it. A store extension frozen at one version for months while its neighbors auto-update is itself a delisting tell.
- **Filter extension inventories to `InstallMethod=2` (user installs).** Mainstream defaults fall away and the discretionary installs — where a rogue one lives — stand out. See §2 #12.
- **DNS attributes to the process (`chrome.exe`), not the extension.** "The extension made the callout" stays *inference* (name + host + profile + overlapping window); the extension's malicious identity is what's independently confirmed. Keep the two claims separate in the writeup.

**More lessons from the HUNT-16 npcap / packet-capture hunt (2026-07-11):**
- **Put a canary in EVERY negative query — it saved this hunt three times.** Q10 returned exactly 1,000 rows (the sort cap) with the canary missing → truncation, not a clean fleet (`.etl` matched Windows Error Reporting files fleet-wide and pushed the known-true row off the bottom). Q11 returned 50 clean rows with the canary *still* missing → that absence **was** the finding (pcap writes don't register at all). In both cases the flaw was invisible except through the canary. **A negative without a canary is indistinguishable from a broken filter.**
- **Noisy identities poison OR-groups — split the query by population.** Adding `UserName=/^itadmin$/i` (a privileged shared account) to an OR alongside three job-specific tests let its million-row baseline consume the entire 1,000-row cap; the interesting tests never surfaced. The operator's fix was right: **two queries, one per population** (fleet-wide process test / single-host test), so each gets its own cap. Companion to pitfalls #3 and #14.
- **"The host went quiet" is a measurement; "the activity stopped" is a conclusion.** When the capture host went silent, the honest next question was *did the job move?* — not *good, it's over*. Test what survives a rebuild: the **hostname** (returns on a new `aid`), the **account** (carries to another box), and above all the **job's own fingerprint** (a fixed output path like `C:\drop.pcap` is durable and unique). Fleet-wide sweep for the fingerprint is what actually closed it.
- **Non-interactive parent is the discriminator for dual-use tooling — but tier it.** Nearly every legitimate capture in a year was a human opening Wireshark; the one anomaly was a capture tool spawned by the Task Scheduler. **Scheduler/service parent (`svchost|taskeng|taskhostw|services`) = 1 TP, 0 FP fleet-wide over 1y → alert.** **Shell parent (`cmd|powershell|wscript|cscript`) is ambiguous** — a human in a console is indistinguishable from a script — → hunt queue, not alert. Favorites #14. Generalizes to any dual-use tool whose benign population is interactive.
- **Verify a rule's precision at the COMMAND-LINE level, not the row level.** I claimed the capture rule was "1 TP / 0 FP after excluding `-r`" — wrong. `CommandLine!=/\s-r/` filters *events*, but a `groupBy` row carries a `collect()` of many command lines; one surviving row had five, only one of which contained `-r`, and the other four were live captures. The row sailed through the exclusion. **Read the individual command lines inside surviving rows before quoting precision.** Caught only by an adversarial re-check of the report against the raw exports.
- **Adversarially fact-check the finished report against the raw exports.** A verification pass over HUNT-16's draft (every number re-derived from the CSVs) found: the install count off by 3× (29 groupBy *rows* ≠ 84 *executions*), host count 24 vs 30, a "one hash per version" headline that was false as written (retail and `-oem` builds are different binaries — true claim is *one hash per **build***), the "heaviest user" attributed to the wrong person, a **second DC capture session nine days later** that the draft missed entirely, and a **second shared privileged account (`Administrator`, ~131 capture runs)** the draft never mentioned. **Aggregated group rows are not event counts, and a claim you formed early survives into the report unless something actively attacks it.**
- **A scheduled task older than retention cannot be attributed from telemetry.** No `ScheduledTaskRegistered` event = the task predates the window, full stop. Say so plainly in the report and hand the attribution question to asset records / change history rather than implying the evidence is ambiguous.

**More lessons from the HUNT-15 custom-IOA triage (2026-07-11):**
- **Baseline triage order for scary counts: time-shape → identity → fleet.** A count without a denominator isn't a finding. Check the span first (incidents cluster around a moment; installed software hums flat across the whole window), then resolve which binary emits it; only spend a fleet-comparison query if the first two lenses leave doubt. HUNT-15 dispositioned ~9.9k detect-family events (`InjectedThread`, `SAMHashDumpFromUnsignedModule`, `RansomwareOpenFile`…) with the first two lenses alone.
- **Put a canary in negative queries.** Scope every "is there anything else?" query so a known positive must appear (HUNT-15 Q03: the detection under investigation had to return). A negative with the canary present is evidence; a negative without one is indistinguishable from a broken filter or wrong field name.

---

## 5. Snippets that worked here (copy/adapt)

```cql
// List repositories by volume
| groupBy(#repo, function=count(as=events), limit=20000)
| sort(events, order=desc, limit=200)
```

```cql
// Windows bad-password failures (SubStatus stored as DECIMAL)
#event_simpleName=UserLogonFailed2 event_platform=Win
| SubStatus="3221225578"
| table([@timestamp, ComputerName, UserName, LogonType, SubStatus], limit=20000)
```

```cql
// Okta: rank anomalous reasons (rare first)
#repo=okta
| groupBy(event.reason, function=[count(as=cnt), min(@timestamp, as=first_seen),
          collect([network.application, user.name], limit=5)], limit=20000)
| sort(cnt, order=asc, limit=200)
```

```cql
// Wide-net field discovery (empty columns drop out)
#repo=detections | Tactic="Privilege Escalation"
| table([@timestamp, aid, ComputerName, Hostname, device.hostname,
         UserName, UserSid, LocalIP, DetectName, SeverityName], limit=20000)
```

```cql
// Okta: extract real target account from agentless-IWA free text, rank targets
#repo=okta #event.outcome=failure event.action="system.iwa_agentless.auth"
| event.reason=/result=(?<auth_result>\w+) for client=(?<target_acct>[^@]+)@/i
| groupBy(target_acct, function=[count(as=attempts), collect([auth_result], limit=10)], limit=20000)
| sort(attempts, order=desc, limit=200)
```

```cql
// Okta: low-and-slow landing test — same account FAILED + SUCCEEDED from same external IP
//   (no volume floor; ascending sort surfaces single-success needles; exclude oakgov egress + placeholder)
#repo=okta event.action=/user\.(authentication|session\.start)/i
| user.name!="system@okta.com"
| client.ip!=/^12\.43\.(10|11)\./
| case { #event.outcome=success | s := 1 ; * | s := 0 }
| case { #event.outcome=failure | f := 1 ; * | f := 0 }
| groupBy([user.name, client.ip], function=[sum(f, as=failures), sum(s, as=successes)], limit=20000)
| failures >= 2 | successes >= 1
| sort(successes, order=asc, limit=2000)
// Then triage by IP ownership: same-domain cluster = partner NAT (benign); cross-org cluster on hosting/VPN = investigate.
```

```cql
// Windows firewall disable attempts (T1562.004)
#repo=base_sensor event_platform=Win event_simpleName=ProcessRollup2
| CommandLine=/(netsh\s+(advfirewall|firewall).*(state\s+off|opmode\s+disable))|(Set-NetFirewallProfile.*-Enabled\s+(False|0))|(Stop-Service.*mpssvc)/i
| table([@timestamp, ComputerName, UserName, ParentBaseFileName, FileName, CommandLine], limit=20000)
```

```cql
// Airtight-tail universe query — enumerate the FULL set of distinct values in a
// categorical dimension (defeats pitfall #14). Substitute the categorical field
// and the population filter. Example: full parent-process universe for chrome/msedge
// --headless, showing rare parents that a per-tuple sort would bury.
#repo=base_sensor event_platform=Win #event_simpleName=ProcessRollup2
| in(field=FileName, values=["chrome.exe", "msedge.exe"])
| CommandLine=/--headless(=new)?\b/i
| groupBy(ParentBaseFileName, function=[
    count(as=hits),
    count(ComputerName, distinct=true, as=distinct_hosts),
    count(UserName, distinct=true, as=distinct_users),
    min(@timestamp, as=first_seen),
    max(@timestamp, as=last_seen)
  ], limit=20000)
| sort(hits, order=desc, limit=200)
// distinct_hosts / distinct_users distinguish widespread environmental patterns
// (fleet-wide parent) from targeted anomalies (single-host/single-user parent).
```
