# Hunt Final Report — Template & Checklist

*Built from a review of all 32 folders in `hunt/` (HUNT-01 → HUNT-32) and the 27 report-type documents inside them. Pairs with `kb/tahiti-is-a-magical-place.md` (method), `kb/crowdstrike-query-playbook.md` (query standards), and `kb/crowdstrike-hunt-lessons-learned.md`.*

**How to use it.** Copy the skeleton below to `hunt-NN/hunt-NN-report-<codename>-YYYY-MM-DD.md` and fill it in. Required sections are marked **[R]**. Optional modules are marked **[O]**; keep the ones that fit the hunt type and delete the rest. Run the pocket checklist on the draft before you mark the hunt CLOSED.

**Where the content comes from.** The hypotheses, their proven-by and disproven-by criteria, and the threat intelligence carry over from the hunt's `abstract.md`. Nothing records the items below while the hunt runs. Infer them at the conclusion of the hunt from what was observed: the abstract, the query files, the exports, and the file dates in the hunt folder.

- Disposition and confidence.
- Opened and closed dates, and the query and session counts.
- Data window and timezone.
- Subject, telemetry, team, and reviewer.
- The visibility ceiling.
- Each query's row count and canary, and which zeros were guarded.

Where one of these cannot be inferred from what was observed, write "not recorded". Do not guess.

---

## The report skeleton

````markdown
# HUNT-NN — "<Mystery Title>"
*<One plain-language line: what was hunted, on what, and the answer.>*

| | |
|---|---|
| **Hunt ID** | HUNT-NN |
| **Status** | CLOSED <date> · or OPEN — <what is blocking> |
| **Outcome** | H1 <PROVEN / DISPROVEN / INCONCLUSIVE> · H0 <PROVEN / DISPROVEN / INCONCLUSIVE> · one entry for each sub-hypothesis |
| **Disposition** | <true positive / benign / false positive (rule) / exposure / governance finding> |
| **Confidence** | <High / Moderate / Low> — <one clause on why> |
| **Opened → closed** | YYYY-MM-DD → YYYY-MM-DD · <n> queries · <n> sessions |
| **Data window** | <start → end> · times shown in <America/Detroit or UTC — pick one, state it> |
| **Subject** | <host · aid · user (name, role, dept)> or <fleet / population> |
| **Telemetry** | <#repo=base_sensor, detections, okta …> |
| **ATT&CK tested** | <T-codes> |
| **Lineage** | Spun off from <HUNT-xx / alert / intel> · Spawned <HUNT-yy, backlog F1–Fn> |
| **Team** | Analyst <name> · AI copilot <Claude> · Reviewer <name> |

---

## 1. Bottom line  [R]
<The first sentence is the verdict. Then 2–3 short paragraphs: what triggered the hunt, what the evidence shows, what is still open, and the single most important action. A reader who stops here should know whether anyone needs to act.>

## 2. Trigger  [R]
- **Source:** <Falcon detection (PatternId, severity) / intel report / prior hunt / operator question>
- **Observation (verbatim):** <the event, the alert card, or the intel claim, as received>
- **Why accepted:** <relevant: risk to this org · huntable: telemetry exists>
- **Held non-IOCs:** <things that look damning but are not evidence on their own (a filename, a GUID, a "random" name)>

## 3. Hypotheses & outcomes  [R]
Carry the IDs, statements, and criteria over from the Hypotheses table in `abstract.md`. The proven-by and disproven-by criteria are AI-generated: the AI drafted them and the analyst approved them. An entry the analyst rewrote is marked (user).
| ID | Statement (falsifiable) | Would be PROVEN by (AI-generated) | Would be DISPROVEN by (AI-generated) | Final outcome | Decisive evidence |
|---|---|---|---|---|---|
| H1 | <the hypothesis under test> | | | | Q0x / export-0x |
| H2 | <sub-hypothesis: a narrower claim or an alternative explanation, e.g. insider> | | | | |
| H0 | <benign / null explanation> | | | | |

Outcomes: **PROVEN · DISPROVEN · INCONCLUSIVE**. For INCONCLUSIVE, name the cause: insufficient data, the wrong analysis technique, a scope that was too narrow, or a hypothesis that was wrong. Keep the TaHiTI *outcome* separate from the *disposition* (benign, FP, TP): "DISPROVEN" says what happened to the hypothesis, and "false positive" says what to do with the alert.

## 4. Scope, data & visibility  [R]
- **Population / window:** <hosts, users, aids · dates · why this window>
- **Data sources used:** <repos, event families>
- **Visibility ceiling (stated up front):** <what this telemetry cannot see: phones, OT field devices, M365/email, unmanaged hosts, inside-session identity, file contents, pre-retention events>

## 5. Timeline  [O — single-host / incident hunts]
| Time (<TZ>) | Event | Source |
|---|---|---|

## 6. Threat model tested vs. observed  [O — any hunt that has a kill-chain hypothesis]
| Stage | ATT&CK | Hypothesized | Observed |
|---|---|---|---|
| Delivery | | | |
| Execution | | | |
| Persistence | | | |
| C2 / exfil | | | |

## 7. Method & evidence trace  [R]
One query per TaHiTI/OODA turn. Each query file has exactly one export with the same number.
| # | Query → export | Question asked | Rows | Canary? | Result (with the real numbers) |
|---|---|---|---|---|---|
| 01 | `query-01.txt` → `export-01.csv` | | | ✓ / ✗ / n/a | |

*Discarded or superseded iterations:* <list them so the numbering gaps make sense>
*Operator-authored queries:* <mark which ones>

## 8. Findings  [R]
Number every finding. Tag each claim **Fact** (visible in an export, with the count, row, or value) or **Inference** (reasoning on top of an export).
- **F1 — <headline>.** <claim> · Evidence: <Q/export refs> · Confidence: <H/M/L>
- **F2 — …**
- **Findings beyond the verdict:** <incidental discoveries: misconfigurations, governance gaps, telemetry facts>

## 9. What the negatives are worth & limitations  [R]
- **Guarded zeros:** <each "nothing found" claim, the canary that proves the query could have found it, and whether the canary appeared>
- **Unguarded zeros:** <zeros without a canary, stated plainly>
- **Truncation / caps / sampling:** <row caps hit, bounded streams, counts that are only floors>
- **Retention & attribution ceilings:** <what predates retention; process-level attribution limits (e.g., chrome network service)>
- **Verdict scope:** <what this report does NOT certify>

## 10. Handover  [R]
| # | Action | Receiving process | Owner | Due | Artifact / detail | Accepted? |
|---|---|---|---|---|---|---|
| 1 | | IR / SOC / Detection eng / IAM / Network / TI / Vuln mgmt / Asset owner | | | | |

**Detection-engineering candidates** [O]: <rule logic or query file · measured baseline (hits/period, TP/FP at the command-line level) · exclusions · severity>
**Indicators** [O]: <defanged IOCs · blocklist status, or an explicit DO-NOT-BLOCK with the reason>

## 11. Spawned hunts / backlog  [R if any threads surfaced]
| # | Candidate hunt | Trigger evidence from this hunt | Suggested first query |
|---|---|---|---|

## 12. Lessons learned  [R]
- **Method:** <what moved the hunt forward or slowed it>
- **Tenant facts:** <field behaviour, baselines, and naming learned in this environment>
- **Corrections of record:** <assumptions that turned out wrong, including the trigger's own premise>

## 13. Artifact index  [R]
| File | What it is |
|---|---|

## 14. Verification & change log  [R]
- **Fact-check pass:** <date · by whom · every number re-derived from the raw exports? Y/N · corrections made>
- **Rev history:** <rev · date · what changed>
````

### Optional modules by hunt type

| Hunt type (corpus examples) | Add | Emphasize |
|---|---|---|
| **Alert triage** — Falcon / custom-IOA / intel-domain hit (08, 15, 21, 22, 28, 32) | Detection metadata block (PatternId, severity, disposition, rule ID) inside §2 | Rule economics in §8 (raw matches → console detections) and tuning in §10 |
| **IOC / intel sweep** (07, 11, 13, 18) | Normalized IOC table, one row per category, with hit count and canary | One guarded zero per IOC category in §9 |
| **Proactive TTP / coverage** (02, 03, 10, 16) | Known-good baseline produced, with its file name | Measured detection candidate in §10 |
| **User / insider question** (14-student, 19, 29) | "Answers to the questions asked" as a numbered list right after §1 | Assumption audit in §12 |
| **Exposure / OT** (24, 26) | "What the estate actually is" before §3 | §4 visibility ceiling and §9 carry the verdict, so give them the most space |
| **Incident RCA** (23) | Root-cause stack · corrections to circulating narratives · outstanding evidence requests | Ordering constraints in remediation |
| **Identity / Okta** (01, 31) | Per-account evidence blocks | Accounts dispositioned benign, each with its reason |

### Pocket checklist (before you type CLOSED)

- [ ] First sentence is the verdict; header has outcome, disposition, confidence
- [ ] H0 written, with criteria, and given a final outcome; every sub-hypothesis has one too
- [ ] Visibility ceiling stated before the findings
- [ ] Every finding cites a query/export; query-NN ↔ export-NN match
- [ ] Every "zero" has a canary, or is labeled unguarded
- [ ] Fact vs. inference tagged
- [ ] Each handover row has an owner and receiving process
- [ ] Spawned threads parked in the backlog table, not chased here
- [ ] KB proposals listed; **no `kb/` file touched**
- [ ] Every number re-derived from the raw exports (adversarial fact-check)
- [ ] File named `hunt-NN-report-<codename>-YYYY-MM-DD.md`

---

